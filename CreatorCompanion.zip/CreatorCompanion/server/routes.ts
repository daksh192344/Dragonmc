import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertCreatorProfileSchema, 
  insertSponsorProfileSchema,
  insertTaskSchema
} from "@shared/schema";
import { generateContentIdeas, getFitnessRecommendations, processAIChatMessage } from "./gemini";

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUsername = await storage.getUserByUsername(userData.username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already taken" });
      }
      
      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already registered" });
      }
      
      const user = await storage.createUser(userData);
      
      // Remove password from response
      const { password, ...userResponse } = user;
      
      res.status(201).json(userResponse);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Remove password from response
      const { password: _, ...userResponse } = user;
      
      res.json(userResponse);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Creator Profile routes
  app.post("/api/creator-profiles", async (req, res) => {
    try {
      const profileData = insertCreatorProfileSchema.parse(req.body);
      
      // Check if user exists
      const user = await storage.getUser(profileData.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if creator profile already exists for user
      const existingProfile = await storage.getCreatorProfileByUserId(profileData.userId);
      if (existingProfile) {
        return res.status(400).json({ message: "Creator profile already exists for this user" });
      }
      
      const profile = await storage.createCreatorProfile(profileData);
      
      res.status(201).json(profile);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/creator-profiles/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const profile = await storage.getCreatorProfile(id);
      
      if (!profile) {
        return res.status(404).json({ message: "Creator profile not found" });
      }
      
      res.json(profile);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/creator-profiles/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const profile = await storage.getCreatorProfileByUserId(userId);
      
      if (!profile) {
        return res.status(404).json({ message: "Creator profile not found" });
      }
      
      res.json(profile);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Sponsor Profile routes
  app.post("/api/sponsor-profiles", async (req, res) => {
    try {
      const profileData = insertSponsorProfileSchema.parse(req.body);
      
      // Check if user exists
      const user = await storage.getUser(profileData.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if sponsor profile already exists for user
      const existingProfile = await storage.getSponsorProfileByUserId(profileData.userId);
      if (existingProfile) {
        return res.status(400).json({ message: "Sponsor profile already exists for this user" });
      }
      
      const profile = await storage.createSponsorProfile(profileData);
      
      res.status(201).json(profile);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/sponsor-profiles/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const profile = await storage.getSponsorProfile(id);
      
      if (!profile) {
        return res.status(404).json({ message: "Sponsor profile not found" });
      }
      
      res.json(profile);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/sponsor-profiles/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const profile = await storage.getSponsorProfileByUserId(userId);
      
      if (!profile) {
        return res.status(404).json({ message: "Sponsor profile not found" });
      }
      
      res.json(profile);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Minecraft Server routes
  app.get("/api/minecraft-servers", async (req, res) => {
    try {
      const servers = await storage.getAllMinecraftServers();
      res.json(servers);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/minecraft-servers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const server = await storage.getMinecraftServer(id);
      
      if (!server) {
        return res.status(404).json({ message: "Minecraft server not found" });
      }
      
      res.json(server);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Creator Resources routes
  app.get("/api/creator-resources", async (req, res) => {
    try {
      const category = req.query.category as string | undefined;
      
      let resources;
      if (category) {
        resources = await storage.getCreatorResourcesByCategory(category);
      } else {
        resources = await storage.getAllCreatorResources();
      }
      
      res.json(resources);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/creator-resources/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const resource = await storage.getCreatorResource(id);
      
      if (!resource) {
        return res.status(404).json({ message: "Creator resource not found" });
      }
      
      res.json(resource);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Task routes
  app.post("/api/tasks", async (req, res) => {
    try {
      const taskData = insertTaskSchema.parse(req.body);
      
      // Check if user exists
      const user = await storage.getUser(taskData.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const task = await storage.createTask(taskData);
      
      res.status(201).json(task);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/tasks/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const tasks = await storage.getTasksByUserId(userId);
      
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/tasks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const task = await storage.getTask(id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      const updatedTask = await storage.updateTask(id, req.body);
      
      res.json(updatedTask);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/tasks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const task = await storage.getTask(id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      const success = await storage.deleteTask(id);
      
      if (success) {
        return res.status(204).end();
      } else {
        return res.status(500).json({ message: "Failed to delete task" });
      }
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Fitness Recommendations routes
  app.get("/api/fitness-recommendations", async (req, res) => {
    try {
      const category = req.query.category as string | undefined;
      
      let recommendations;
      if (category) {
        recommendations = await storage.getFitnessRecommendationsByCategory(category);
      } else {
        recommendations = await storage.getAllFitnessRecommendations();
      }
      
      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Business Ideas routes
  app.get("/api/business-ideas", async (req, res) => {
    try {
      const category = req.query.category as string | undefined;
      
      let ideas;
      if (category) {
        ideas = await storage.getBusinessIdeasByCategory(category);
      } else {
        ideas = await storage.getAllBusinessIdeas();
      }
      
      res.json(ideas);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Learning Resources routes
  app.get("/api/learning-resources", async (req, res) => {
    try {
      const category = req.query.category as string | undefined;
      
      let resources;
      if (category) {
        resources = await storage.getLearningResourcesByCategory(category);
      } else {
        resources = await storage.getAllLearningResources();
      }
      
      res.json(resources);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/learning-resources/:id/progress", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const { progress } = req.body;
      
      if (typeof progress !== 'number' || progress < 0 || progress > 100) {
        return res.status(400).json({ message: "Progress must be a number between 0 and 100" });
      }
      
      const resource = await storage.getLearningResource(id);
      if (!resource) {
        return res.status(404).json({ message: "Learning resource not found" });
      }
      
      const updatedResource = await storage.updateLearningResourceProgress(id, progress);
      
      res.json(updatedResource);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Matching routes
  app.get("/api/match/creators", async (req, res) => {
    try {
      const budget = req.query.budget ? parseInt(req.query.budget as string) : 0;
      const industry = req.query.industry as string | undefined;
      
      if (isNaN(budget)) {
        return res.status(400).json({ message: "Invalid budget" });
      }
      
      const creators = await storage.findCreatorsForSponsor(budget, industry);
      
      res.json(creators);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/match/sponsors", async (req, res) => {
    try {
      const minBudget = req.query.minBudget ? parseInt(req.query.minBudget as string) : 0;
      const niche = req.query.niche as string | undefined;
      
      if (isNaN(minBudget)) {
        return res.status(400).json({ message: "Invalid minimum budget" });
      }
      
      const sponsors = await storage.findSponsorsForCreator(minBudget, niche);
      
      res.json(sponsors);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // AI endpoints using Google Gemini

  app.post("/api/ai/generate-ideas", async (req, res) => {
    try {
      const { topic } = req.body;
      
      if (!topic) {
        return res.status(400).json({ message: "Topic is required" });
      }
      
      const result = await generateContentIdeas(topic);
      res.json(result);
    } catch (error) {
      console.error("Error in generate-ideas endpoint:", error);
      res.status(500).json({ message: "Failed to generate content ideas" });
    }
  });

  app.post("/api/ai/fitness-recommendation", async (req, res) => {
    try {
      const { schedule, preferences } = req.body;
      
      if (!schedule || !preferences) {
        return res.status(400).json({ message: "Schedule and preferences are required" });
      }
      
      const result = await getFitnessRecommendations(schedule, preferences);
      res.json(result);
    } catch (error) {
      console.error("Error in fitness-recommendation endpoint:", error);
      res.status(500).json({ message: "Failed to generate fitness recommendations" });
    }
  });
  
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const { message, context } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }
      
      const response = await processAIChatMessage(message, context);
      res.json({ response });
    } catch (error) {
      console.error("Error in chat endpoint:", error);
      res.status(500).json({ message: "Failed to process chat message" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
