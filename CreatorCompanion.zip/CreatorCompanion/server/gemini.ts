import { GoogleGenerativeAI, GenerativeModel } from '@google/generative-ai';

// Initialize the Gemini AI client
const genAI = new GoogleGenerativeAI(process.env.GOOGLE_GEMINI_API_KEY || '');
// Using the latest Gemini model
const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });

/**
 * Generate content ideas based on a topic
 * @param topic The topic to generate ideas for
 * @returns A promise with the generated ideas
 */
export async function generateContentIdeas(topic: string): Promise<{
  ideas: Array<{ title: string; description: string }>;
}> {
  try {
    const prompt = `
    Generate 4 content ideas for a creator focused on "${topic}".
    For each idea, provide a catchy title and a brief description.
    Format the response as a JSON object with an "ideas" array containing objects with "title" and "description" properties.
    `;

    const result = await model.generateContent(prompt);
    const response = result.response;
    const text = response.text();
    
    // Extract JSON from the response
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      try {
        const parsedData = JSON.parse(jsonMatch[0]);
        return parsedData;
      } catch (parseError) {
        console.error("Failed to parse JSON from Gemini response:", parseError);
      }
    }
    
    // Fallback parsing if JSON extraction fails
    // Parse the response text as a list of ideas
    const ideas = [];
    const lines = text.split('\n').filter(line => line.trim());
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (line.match(/^\d+\./) || line.match(/^-/) || line.match(/^•/)) {
        const titleMatch = line.replace(/^\d+\.|-|•/, '').trim();
        const descMatch = lines[i + 1]?.trim();
        
        if (titleMatch && descMatch && !descMatch.match(/^\d+\.|-|•/)) {
          ideas.push({
            title: titleMatch,
            description: descMatch
          });
          i++; // Skip the description line
        } else if (titleMatch) {
          // If there's no clear description, use the title as both
          ideas.push({
            title: titleMatch,
            description: `Explore interesting aspects of ${titleMatch} for your audience.`
          });
        }
      }
    }
    
    // If we couldn't parse any ideas, return a fallback
    if (ideas.length === 0) {
      throw new Error("Failed to parse ideas from Gemini response");
    }
    
    return { ideas: ideas.slice(0, 4) }; // Limit to 4 ideas
  } catch (error) {
    console.error("Error generating content ideas:", error);
    throw new Error("Failed to generate content ideas");
  }
}

/**
 * Get fitness recommendations based on user preferences
 * @param schedule User's schedule information
 * @param preferences User's preferences
 * @returns A promise with fitness recommendations
 */
export async function getFitnessRecommendations(
  schedule: { days: number; timePerDay: number },
  preferences: { focus: string; experience: string }
): Promise<{
  recommendations: Array<{ title: string; description: string; duration: number }>;
}> {
  try {
    const prompt = `
    Generate 4 fitness recommendations for someone with the following schedule and preferences:
    Schedule: ${schedule.days} days per week, ${schedule.timePerDay} minutes per day
    Focus: ${preferences.focus}
    Experience level: ${preferences.experience}
    
    For each recommendation, provide a title, description, and duration in minutes.
    Format the response as a JSON object with a "recommendations" array containing objects with "title", "description", and "duration" properties.
    `;

    const result = await model.generateContent(prompt);
    const response = result.response;
    const text = response.text();
    
    // Extract JSON from the response
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      try {
        const parsedData = JSON.parse(jsonMatch[0]);
        return parsedData;
      } catch (parseError) {
        console.error("Failed to parse JSON from Gemini response:", parseError);
      }
    }
    
    // Fallback parsing if JSON extraction fails
    const recommendations = [];
    const lines = text.split('\n').filter(line => line.trim());
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (line.match(/^\d+\./) || line.match(/^-/) || line.match(/^•/)) {
        const titleMatch = line.replace(/^\d+\.|-|•/, '').trim();
        const descMatch = lines[i + 1]?.trim();
        
        if (titleMatch && descMatch && !descMatch.match(/^\d+\.|-|•/)) {
          recommendations.push({
            title: titleMatch,
            description: descMatch,
            duration: Math.floor(Math.random() * 10) + 5 // Random duration between 5-15 minutes
          });
          i++; // Skip the description line
        }
      }
    }
    
    // If we couldn't parse any recommendations, return a fallback
    if (recommendations.length === 0) {
      throw new Error("Failed to parse recommendations from Gemini response");
    }
    
    return { recommendations: recommendations.slice(0, 4) }; // Limit to 4 recommendations
  } catch (error) {
    console.error("Error generating fitness recommendations:", error);
    throw new Error("Failed to generate fitness recommendations");
  }
}

/**
 * Process a chat message with AI
 * @param message The user's message
 * @param context Optional context from previous messages
 * @returns A promise with the AI response
 */
export async function processAIChatMessage(
  message: string,
  context?: string
): Promise<string> {
  try {
    let prompt = message;
    
    if (context) {
      prompt = `Previous context: ${context}\n\nUser message: ${message}`;
    }
    
    const chat = model.startChat({
      history: context ? [
        {
          role: "user",
          parts: [{ text: context }],
        },
        {
          role: "model",
          parts: [{ text: "I understand the context. How can I help you today?" }],
        }
      ] : [],
      generationConfig: {
        maxOutputTokens: 1000,
      },
    });
    
    const result = await chat.sendMessage(message);
    const response = result.response;
    return response.text();
  } catch (error) {
    console.error("Error processing chat message:", error);
    throw new Error("Failed to process chat message");
  }
}