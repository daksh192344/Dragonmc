import { Mistral } from '@mistralai/mistralai';

// Initialize the Mistral AI client
const mistral = new Mistral({ apiKey: process.env.MISTRAL_API_KEY || '' });

// Current best model for general use
const MISTRAL_MODEL = "mistral-large-latest";

/**
 * Generate content ideas based on a topic
 * @param topic The topic to generate ideas for
 * @returns A promise with the generated ideas
 */
export async function generateContentIdeas(topic: string): Promise<{
  ideas: Array<{ title: string; description: string }>;
}> {
  try {
    const response = await mistral.chat.complete({
      model: MISTRAL_MODEL,
      messages: [
        {
          role: 'system',
          content: 'You are a creative content strategy assistant. Generate creative and engaging content ideas for the given topic. Provide a title and brief description for each idea.'
        },
        {
          role: 'user',
          content: `Generate 3-5 content ideas for the topic: ${topic}. Format the response as JSON with an array of objects, each having a "title" and "description" field.`
        }
      ],
      responseFormat: { type: 'json_object' },
    });

    if (!response.choices?.[0]?.message?.content) {
      throw new Error('Invalid API response format');
    }

    const responseContent = response.choices[0].message.content;
    const parsedContent = JSON.parse(responseContent);
    
    return { ideas: parsedContent.ideas || [] };
  } catch (error) {
    console.error('Error generating content ideas:', error);
    throw new Error('Failed to generate content ideas');
  }
}

/**
 * Get fitness recommendations based on user preferences
 * @param schedule User's schedule information
 * @param preferences User's preferences
 * @returns A promise with fitness recommendations
 */
export async function getFitnessRecommendations(
  schedule?: { workHours: string; breakTimes: string },
  preferences?: { focus: string; difficulty: string }
): Promise<{
  recommendations: Array<{ title: string; description: string; duration: number }>;
}> {
  try {
    const schedulePrompt = schedule 
      ? `Work hours: ${schedule.workHours}, Break times: ${schedule.breakTimes}.` 
      : 'No specific schedule provided.';
    
    const preferencesPrompt = preferences 
      ? `Focus areas: ${preferences.focus}, Difficulty level: ${preferences.difficulty}.` 
      : 'No specific preferences provided.';

    const response = await mistral.chat.complete({
      model: MISTRAL_MODEL,
      messages: [
        {
          role: 'system',
          content: 'You are a fitness coach specializing in recommending exercises for content creators who spend long hours at their desk. Create practical, effective exercises that can be done in short breaks during the workday.'
        },
        {
          role: 'user',
          content: `Provide 3-5 fitness recommendations for a content creator with the following information:
          ${schedulePrompt}
          ${preferencesPrompt}
          Format the response as JSON with an array of objects, each having "title", "description", and "duration" (in minutes) fields.`
        }
      ],
      responseFormat: { type: 'json_object' },
    });

    if (!response.choices?.[0]?.message?.content) {
      throw new Error('Invalid API response format');
    }

    const responseContent = response.choices[0].message.content;
    const parsedContent = JSON.parse(responseContent);
    
    return { recommendations: parsedContent.recommendations || [] };
  } catch (error) {
    console.error('Error generating fitness recommendations:', error);
    throw new Error('Failed to generate fitness recommendations');
  }
}

/**
 * Process a chat message with AI
 * @param message The user's message
 * @param context Optional context from previous messages
 * @returns A promise with the AI response
 */
export async function processAIChatMessage(
  message: string,
  context?: Array<{ role: "user" | "assistant"; content: string }>
): Promise<string> {
  try {
    // Type for message roles
    type MessageRole = "system" | "user" | "assistant";
    
    // Prepare messages array with proper typing
    const messages: Array<{ role: MessageRole; content: string }> = [];
    
    // Add the system message at the beginning if no context
    if (!context || context.length === 0) {
      messages.push({
        role: 'system',
        content: 'You are a helpful AI assistant for content creators. You provide advice on content strategy, audience growth, monetization options, and technical aspects of content creation.'
      });
    } else {
      // Add context messages
      for (const msg of context) {
        messages.push({
          role: msg.role as MessageRole,
          content: msg.content
        });
      }
    }
    
    // Add the new user message
    messages.push({
      role: 'user',
      content: message
    });

    const response = await mistral.chat.complete({
      model: MISTRAL_MODEL,
      messages,
    });

    if (!response.choices?.[0]?.message?.content) {
      throw new Error('Invalid API response format');
    }

    return response.choices[0].message.content;
  } catch (error) {
    console.error('Error processing chat message:', error);
    throw new Error('Failed to process chat message');
  }
}