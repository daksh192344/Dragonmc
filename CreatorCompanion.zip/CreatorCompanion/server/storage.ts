import { 
  User, InsertUser, 
  CreatorProfile, InsertCreatorProfile,
  SponsorProfile, InsertSponsorProfile,
  MinecraftServer, InsertMinecraftServer,
  CreatorResource, InsertCreatorResource,
  Task, InsertTask,
  FitnessRecommendation, InsertFitnessRecommendation,
  BusinessIdea, InsertBusinessIdea,
  LearningResource, InsertLearningResource
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Creator Profile methods
  getCreatorProfile(id: number): Promise<CreatorProfile | undefined>;
  getCreatorProfileByUserId(userId: number): Promise<CreatorProfile | undefined>;
  createCreatorProfile(profile: InsertCreatorProfile): Promise<CreatorProfile>;
  updateCreatorProfile(id: number, profile: Partial<InsertCreatorProfile>): Promise<CreatorProfile | undefined>;
  
  // Sponsor Profile methods
  getSponsorProfile(id: number): Promise<SponsorProfile | undefined>;
  getSponsorProfileByUserId(userId: number): Promise<SponsorProfile | undefined>;
  createSponsorProfile(profile: InsertSponsorProfile): Promise<SponsorProfile>;
  updateSponsorProfile(id: number, profile: Partial<InsertSponsorProfile>): Promise<SponsorProfile | undefined>;
  
  // Minecraft Server methods
  getMinecraftServer(id: number): Promise<MinecraftServer | undefined>;
  getAllMinecraftServers(): Promise<MinecraftServer[]>;
  createMinecraftServer(server: InsertMinecraftServer): Promise<MinecraftServer>;
  
  // Creator Resources methods
  getCreatorResource(id: number): Promise<CreatorResource | undefined>;
  getAllCreatorResources(): Promise<CreatorResource[]>;
  getCreatorResourcesByCategory(category: string): Promise<CreatorResource[]>;
  createCreatorResource(resource: InsertCreatorResource): Promise<CreatorResource>;
  
  // Task methods
  getTask(id: number): Promise<Task | undefined>;
  getTasksByUserId(userId: number): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<InsertTask>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<boolean>;
  
  // Fitness Recommendation methods
  getFitnessRecommendation(id: number): Promise<FitnessRecommendation | undefined>;
  getAllFitnessRecommendations(): Promise<FitnessRecommendation[]>;
  getFitnessRecommendationsByCategory(category: string): Promise<FitnessRecommendation[]>;
  createFitnessRecommendation(recommendation: InsertFitnessRecommendation): Promise<FitnessRecommendation>;
  
  // Business Idea methods
  getBusinessIdea(id: number): Promise<BusinessIdea | undefined>;
  getAllBusinessIdeas(): Promise<BusinessIdea[]>;
  getBusinessIdeasByCategory(category: string): Promise<BusinessIdea[]>;
  createBusinessIdea(idea: InsertBusinessIdea): Promise<BusinessIdea>;
  
  // Learning Resource methods
  getLearningResource(id: number): Promise<LearningResource | undefined>;
  getAllLearningResources(): Promise<LearningResource[]>;
  getLearningResourcesByCategory(category: string): Promise<LearningResource[]>;
  createLearningResource(resource: InsertLearningResource): Promise<LearningResource>;
  updateLearningResourceProgress(id: number, progress: number): Promise<LearningResource | undefined>;
  
  // Match makers
  findCreatorsForSponsor(budget: number, industry?: string): Promise<CreatorProfile[]>;
  findSponsorsForCreator(minBudget: number, niche?: string): Promise<SponsorProfile[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private creatorProfiles: Map<number, CreatorProfile>;
  private sponsorProfiles: Map<number, SponsorProfile>;
  private minecraftServers: Map<number, MinecraftServer>;
  private creatorResources: Map<number, CreatorResource>;
  private tasks: Map<number, Task>;
  private fitnessRecommendations: Map<number, FitnessRecommendation>;
  private businessIdeas: Map<number, BusinessIdea>;
  private learningResources: Map<number, LearningResource>;
  
  private userIdCounter: number;
  private creatorProfileIdCounter: number;
  private sponsorProfileIdCounter: number;
  private minecraftServerIdCounter: number;
  private creatorResourceIdCounter: number;
  private taskIdCounter: number;
  private fitnessRecommendationIdCounter: number;
  private businessIdeaIdCounter: number;
  private learningResourceIdCounter: number;

  constructor() {
    this.users = new Map();
    this.creatorProfiles = new Map();
    this.sponsorProfiles = new Map();
    this.minecraftServers = new Map();
    this.creatorResources = new Map();
    this.tasks = new Map();
    this.fitnessRecommendations = new Map();
    this.businessIdeas = new Map();
    this.learningResources = new Map();
    
    this.userIdCounter = 1;
    this.creatorProfileIdCounter = 1;
    this.sponsorProfileIdCounter = 1;
    this.minecraftServerIdCounter = 1;
    this.creatorResourceIdCounter = 1;
    this.taskIdCounter = 1;
    this.fitnessRecommendationIdCounter = 1;
    this.businessIdeaIdCounter = 1;
    this.learningResourceIdCounter = 1;
    
    this.initializeData();
  }

  private initializeData(): void {
    // Initialize Minecraft Servers
    const minecraftServerData: InsertMinecraftServer[] = [
      {
        name: "SMP",
        price: 30,
        ram: 2,
        gameMode: "Survival Multiplayer",
        players: 10,
        features: ["2GB RAM", "Survival Multiplayer", "10 Player Slots", "24/7 Uptime"],
        popular: false
      },
      {
        name: "OneBlock",
        price: 50,
        ram: 3,
        gameMode: "OneBlock Challenge",
        players: 15,
        features: ["3GB RAM", "OneBlock Challenge", "15 Player Slots", "Custom Progression"],
        popular: false
      },
      {
        name: "BedWars",
        price: 100,
        ram: 4,
        gameMode: "BedWars",
        players: 24,
        features: ["4GB RAM", "BedWars Game Mode", "24 Player Slots", "Multiple Maps"],
        popular: false
      },
      {
        name: "MiniGame",
        price: 150,
        ram: 6,
        gameMode: "Mini Games",
        players: 32,
        features: ["6GB RAM", "Various Mini Games", "32 Player Slots", "Game Rotations"],
        popular: false
      },
      {
        name: "LifeSteal",
        price: 220,
        ram: 8,
        gameMode: "LifeSteal SMP",
        players: 40,
        features: ["8GB RAM", "LifeSteal Mechanics", "40 Player Slots", "Custom Plugins"],
        popular: false
      },
      {
        name: "BoxPVP",
        price: 300,
        ram: 10,
        gameMode: "Box PVP",
        players: 50,
        features: ["10GB RAM", "PVP Arenas", "50 Player Slots", "Custom Kits"],
        popular: false
      },
      {
        name: "SkyBlock",
        price: 450,
        ram: 12,
        gameMode: "SkyBlock",
        players: 60,
        features: ["12GB RAM", "SkyBlock Islands", "60 Player Slots", "Economy System"],
        popular: false
      },
      {
        name: "All Gamemodes",
        price: 750,
        ram: 16,
        gameMode: "All Game Modes",
        players: 100,
        features: ["16GB RAM", "All Game Modes Included", "100 Player Slots", "Priority Support"],
        popular: true
      }
    ];

    for (const server of minecraftServerData) {
      this.createMinecraftServer(server);
    }

    // Initialize Creator Resources
    const creatorResourceData: InsertCreatorResource[] = [
      {
        title: "YouTube Shorts Viral Strategy",
        description: "Learn proven techniques to make your Shorts go viral with our comprehensive guide.",
        category: "guide",
        details: "12 Strategies, 45 min read",
        thumbnail: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3"
      },
      {
        title: "Minecraft Thumbnail Pack",
        description: "Professional thumbnail templates designed specifically for Minecraft content creators.",
        category: "template",
        details: "25 Templates, PSD & PNG",
        thumbnail: "https://images.unsplash.com/photo-1547658719-da2b51169166?ixlib=rb-4.0.3"
      },
      {
        title: "Optimal MC Gaming Setup",
        description: "Complete guide to creating the perfect Minecraft recording and streaming setup.",
        category: "setup",
        details: "Hardware & Software Guide",
        thumbnail: "https://images.unsplash.com/photo-1576097492152-4687ccd1c6ec?ixlib=rb-4.0.3"
      },
      {
        title: "Gaming Video Editing Pack",
        description: "Professional presets, transitions, and effects for Premiere Pro and After Effects.",
        category: "editing",
        details: "50+ Presets & Effects",
        thumbnail: "https://images.unsplash.com/photo-1621839673705-6617adf9e890?ixlib=rb-4.0.3"
      },
      {
        title: "Minecraft Mod Development",
        description: "Learn to create custom Minecraft mods with our beginner-friendly coding guides.",
        category: "coding",
        details: "Java Tutorials & Samples",
        thumbnail: "https://images.unsplash.com/photo-1542831371-29b0f74f9713?ixlib=rb-4.0.3"
      },
      {
        title: "Creator Business Ideas",
        description: "Monetization strategies beyond ad revenue - merchandise, memberships, and more.",
        category: "business",
        details: "15 Business Models",
        thumbnail: "https://images.unsplash.com/photo-1505236858219-8359eb29e329?ixlib=rb-4.0.3"
      }
    ];

    for (const resource of creatorResourceData) {
      this.createCreatorResource(resource);
    }

    // Initialize Fitness Recommendations
    const fitnessRecommendationData: InsertFitnessRecommendation[] = [
      {
        title: "Wrist Stretches",
        description: "Important for long gaming/editing sessions",
        category: "stretching",
        duration: 5
      },
      {
        title: "10-minute Break Walk",
        description: "Schedule short walks between recording sessions",
        category: "cardio",
        duration: 10
      },
      {
        title: "Eye Exercises",
        description: "Reduce strain from screen time",
        category: "eyes",
        duration: 3
      },
      {
        title: "Seated Shoulder Stretches",
        description: "Prevent shoulder pain from long gaming sessions",
        category: "stretching",
        duration: 5
      },
      {
        title: "Mindful Breathing",
        description: "Reduce stress and improve focus before recording",
        category: "mental",
        duration: 5
      }
    ];

    for (const recommendation of fitnessRecommendationData) {
      this.createFitnessRecommendation(recommendation);
    }

    // Initialize Business Ideas
    const businessIdeaData: InsertBusinessIdea[] = [
      {
        title: "Minecraft Tutorial Membership",
        description: "Create a membership site with exclusive tutorials",
        category: "education"
      },
      {
        title: "Custom Server Consultancy",
        description: "Offer services to set up custom servers for other creators",
        category: "service"
      },
      {
        title: "Gaming Merchandise Store",
        description: "Launch custom merchandise based on your content",
        category: "product"
      },
      {
        title: "Creator Coaching Program",
        description: "Mentor new content creators in your niche",
        category: "education"
      },
      {
        title: "Resource Pack Development",
        description: "Create and sell custom Minecraft resource packs",
        category: "product"
      }
    ];

    for (const idea of businessIdeaData) {
      this.createBusinessIdea(idea);
    }

    // Initialize Learning Resources
    const learningResourceData: InsertLearningResource[] = [
      {
        title: "Advanced Video Editing",
        description: "Master advanced video editing techniques for gaming content",
        category: "editing",
        progress: 65
      },
      {
        title: "Thumbnail Design",
        description: "Learn to create eye-catching thumbnails that improve CTR",
        category: "design",
        progress: 40
      },
      {
        title: "Server Configuration",
        description: "Learn how to configure and optimize Minecraft servers",
        category: "technical",
        progress: 20
      },
      {
        title: "Content Strategy",
        description: "Develop a content strategy that grows your channel",
        category: "business",
        progress: 10
      },
      {
        title: "Voice Training",
        description: "Improve your voice and narration for videos",
        category: "performance",
        progress: 5
      }
    ];

    for (const resource of learningResourceData) {
      this.createLearningResource(resource);
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Creator Profile methods
  async getCreatorProfile(id: number): Promise<CreatorProfile | undefined> {
    return this.creatorProfiles.get(id);
  }

  async getCreatorProfileByUserId(userId: number): Promise<CreatorProfile | undefined> {
    return Array.from(this.creatorProfiles.values()).find(
      (profile) => profile.userId === userId
    );
  }

  async createCreatorProfile(insertProfile: InsertCreatorProfile): Promise<CreatorProfile> {
    const id = this.creatorProfileIdCounter++;
    const profile: CreatorProfile = { ...insertProfile, id };
    this.creatorProfiles.set(id, profile);
    return profile;
  }

  async updateCreatorProfile(id: number, profileUpdate: Partial<InsertCreatorProfile>): Promise<CreatorProfile | undefined> {
    const profile = this.creatorProfiles.get(id);
    if (!profile) return undefined;
    
    const updatedProfile = { ...profile, ...profileUpdate };
    this.creatorProfiles.set(id, updatedProfile);
    return updatedProfile;
  }

  // Sponsor Profile methods
  async getSponsorProfile(id: number): Promise<SponsorProfile | undefined> {
    return this.sponsorProfiles.get(id);
  }

  async getSponsorProfileByUserId(userId: number): Promise<SponsorProfile | undefined> {
    return Array.from(this.sponsorProfiles.values()).find(
      (profile) => profile.userId === userId
    );
  }

  async createSponsorProfile(insertProfile: InsertSponsorProfile): Promise<SponsorProfile> {
    const id = this.sponsorProfileIdCounter++;
    const profile: SponsorProfile = { ...insertProfile, id };
    this.sponsorProfiles.set(id, profile);
    return profile;
  }

  async updateSponsorProfile(id: number, profileUpdate: Partial<InsertSponsorProfile>): Promise<SponsorProfile | undefined> {
    const profile = this.sponsorProfiles.get(id);
    if (!profile) return undefined;
    
    const updatedProfile = { ...profile, ...profileUpdate };
    this.sponsorProfiles.set(id, updatedProfile);
    return updatedProfile;
  }

  // Minecraft Server methods
  async getMinecraftServer(id: number): Promise<MinecraftServer | undefined> {
    return this.minecraftServers.get(id);
  }

  async getAllMinecraftServers(): Promise<MinecraftServer[]> {
    return Array.from(this.minecraftServers.values());
  }

  async createMinecraftServer(insertServer: InsertMinecraftServer): Promise<MinecraftServer> {
    const id = this.minecraftServerIdCounter++;
    const server: MinecraftServer = { ...insertServer, id };
    this.minecraftServers.set(id, server);
    return server;
  }

  // Creator Resources methods
  async getCreatorResource(id: number): Promise<CreatorResource | undefined> {
    return this.creatorResources.get(id);
  }

  async getAllCreatorResources(): Promise<CreatorResource[]> {
    return Array.from(this.creatorResources.values());
  }

  async getCreatorResourcesByCategory(category: string): Promise<CreatorResource[]> {
    return Array.from(this.creatorResources.values()).filter(
      (resource) => resource.category === category
    );
  }

  async createCreatorResource(insertResource: InsertCreatorResource): Promise<CreatorResource> {
    const id = this.creatorResourceIdCounter++;
    const resource: CreatorResource = { ...insertResource, id };
    this.creatorResources.set(id, resource);
    return resource;
  }

  // Task methods
  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async getTasksByUserId(userId: number): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(
      (task) => task.userId === userId
    );
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = this.taskIdCounter++;
    const task: Task = { ...insertTask, id };
    this.tasks.set(id, task);
    return task;
  }

  async updateTask(id: number, taskUpdate: Partial<InsertTask>): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;
    
    const updatedTask = { ...task, ...taskUpdate };
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }

  async deleteTask(id: number): Promise<boolean> {
    return this.tasks.delete(id);
  }

  // Fitness Recommendation methods
  async getFitnessRecommendation(id: number): Promise<FitnessRecommendation | undefined> {
    return this.fitnessRecommendations.get(id);
  }

  async getAllFitnessRecommendations(): Promise<FitnessRecommendation[]> {
    return Array.from(this.fitnessRecommendations.values());
  }

  async getFitnessRecommendationsByCategory(category: string): Promise<FitnessRecommendation[]> {
    return Array.from(this.fitnessRecommendations.values()).filter(
      (recommendation) => recommendation.category === category
    );
  }

  async createFitnessRecommendation(insertRecommendation: InsertFitnessRecommendation): Promise<FitnessRecommendation> {
    const id = this.fitnessRecommendationIdCounter++;
    const recommendation: FitnessRecommendation = { ...insertRecommendation, id };
    this.fitnessRecommendations.set(id, recommendation);
    return recommendation;
  }

  // Business Idea methods
  async getBusinessIdea(id: number): Promise<BusinessIdea | undefined> {
    return this.businessIdeas.get(id);
  }

  async getAllBusinessIdeas(): Promise<BusinessIdea[]> {
    return Array.from(this.businessIdeas.values());
  }

  async getBusinessIdeasByCategory(category: string): Promise<BusinessIdea[]> {
    return Array.from(this.businessIdeas.values()).filter(
      (idea) => idea.category === category
    );
  }

  async createBusinessIdea(insertIdea: InsertBusinessIdea): Promise<BusinessIdea> {
    const id = this.businessIdeaIdCounter++;
    const idea: BusinessIdea = { ...insertIdea, id };
    this.businessIdeas.set(id, idea);
    return idea;
  }

  // Learning Resource methods
  async getLearningResource(id: number): Promise<LearningResource | undefined> {
    return this.learningResources.get(id);
  }

  async getAllLearningResources(): Promise<LearningResource[]> {
    return Array.from(this.learningResources.values());
  }

  async getLearningResourcesByCategory(category: string): Promise<LearningResource[]> {
    return Array.from(this.learningResources.values()).filter(
      (resource) => resource.category === category
    );
  }

  async createLearningResource(insertResource: InsertLearningResource): Promise<LearningResource> {
    const id = this.learningResourceIdCounter++;
    const resource: LearningResource = { ...insertResource, id };
    this.learningResources.set(id, resource);
    return resource;
  }

  async updateLearningResourceProgress(id: number, progress: number): Promise<LearningResource | undefined> {
    const resource = this.learningResources.get(id);
    if (!resource) return undefined;
    
    const updatedResource = { ...resource, progress };
    this.learningResources.set(id, updatedResource);
    return updatedResource;
  }

  // Match makers
  async findCreatorsForSponsor(budget: number, industry?: string): Promise<CreatorProfile[]> {
    return Array.from(this.creatorProfiles.values()).filter(
      (profile) => profile.minBudget <= budget
    );
  }

  async findSponsorsForCreator(minBudget: number, niche?: string): Promise<SponsorProfile[]> {
    return Array.from(this.sponsorProfiles.values()).filter(
      (profile) => profile.budget >= minBudget
    );
  }
}

export const storage = new MemStorage();
