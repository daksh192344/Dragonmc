import { generateIdeasEndpoint, fitnessRecommendationsEndpoint } from "./constants";

// A simple utility to interact with the Gemini API via our backend endpoints

/**
 * Generate content ideas based on a topic
 * @param topic The topic to generate ideas for
 * @returns A promise with the generated ideas
 */
export async function generateContentIdeas(topic: string): Promise<{
  ideas: Array<{ title: string; description: string }>;
}> {
  try {
    const response = await fetch(generateIdeasEndpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ topic }),
      credentials: "include",
    });

    if (!response.ok) {
      throw new Error(`Error generating ideas: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Failed to generate ideas:", error);
    throw error;
  }
}

/**
 * Get fitness recommendations based on user preferences
 * @param schedule User's schedule information
 * @param preferences User's preferences
 * @returns A promise with fitness recommendations
 */
export async function getFitnessRecommendations(
  schedule: { days: number; timePerDay: number },
  preferences: { focus: string; experience: string }
): Promise<{
  recommendations: Array<{ title: string; description: string; duration: number }>;
}> {
  try {
    const response = await fetch(fitnessRecommendationsEndpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ schedule, preferences }),
      credentials: "include",
    });

    if (!response.ok) {
      throw new Error(`Error getting fitness recommendations: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Failed to get fitness recommendations:", error);
    throw error;
  }
}

/**
 * Process a chat message with AI
 * @param message The user's message
 * @param context Optional context from previous messages
 * @returns A promise with the AI response
 */
export async function processAIChatMessage(
  message: string,
  context?: string
): Promise<string> {
  try {
    const response = await fetch("/api/ai/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ message, context }),
      credentials: "include",
    });

    if (!response.ok) {
      throw new Error(`Error processing chat message: ${response.statusText}`);
    }

    const data = await response.json();
    return data.response;
  } catch (error) {
    console.error("Failed to process chat message:", error);
    throw error;
  }
}
