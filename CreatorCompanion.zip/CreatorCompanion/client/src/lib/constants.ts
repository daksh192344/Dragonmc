// API Endpoints
export const apiBaseUrl = "/api";

// Authentication
export const loginEndpoint = `${apiBaseUrl}/auth/login`;
export const registerEndpoint = `${apiBaseUrl}/auth/register`;
export const logoutEndpoint = `${apiBaseUrl}/auth/logout`;

// User Profiles
export const userProfileEndpoint = `${apiBaseUrl}/user/profile`;
export const creatorProfileEndpoint = `${apiBaseUrl}/creator-profiles`;
export const sponsorProfileEndpoint = `${apiBaseUrl}/sponsor-profiles`;

// Minecraft Servers
export const minecraftServersEndpoint = `${apiBaseUrl}/minecraft-servers`;

// Creator Resources
export const creatorResourcesEndpoint = `${apiBaseUrl}/creator-resources`;

// Tasks
export const tasksEndpoint = `${apiBaseUrl}/tasks`;

// Fitness Recommendations
export const fitnessRecommendationsEndpoint = `${apiBaseUrl}/fitness-recommendations`;

// Business Ideas
export const businessIdeasEndpoint = `${apiBaseUrl}/business-ideas`;

// Learning Resources
export const learningResourcesEndpoint = `${apiBaseUrl}/learning-resources`;

// AI Endpoints
export const generateIdeasEndpoint = `${apiBaseUrl}/ai/generate-ideas`;
export const fitnessAIEndpoint = `${apiBaseUrl}/ai/fitness-recommendation`;

// Matching
export const matchCreatorsEndpoint = `${apiBaseUrl}/match/creators`;
export const matchSponsorsEndpoint = `${apiBaseUrl}/match/sponsors`;

// Pricing
export const minecraftServerOptions = [
  {
    name: "SMP",
    price: 30,
    features: ["2GB RAM", "Survival Multiplayer", "10 Player Slots", "24/7 Uptime"],
    popular: false
  },
  {
    name: "OneBlock",
    price: 50,
    features: ["3GB RAM", "OneBlock Challenge", "15 Player Slots", "Custom Progression"],
    popular: false
  },
  {
    name: "BedWars",
    price: 100,
    features: ["4GB RAM", "BedWars Game Mode", "24 Player Slots", "Multiple Maps"],
    popular: false
  },
  {
    name: "MiniGame",
    price: 150,
    features: ["6GB RAM", "Various Mini Games", "32 Player Slots", "Game Rotations"],
    popular: false
  },
  {
    name: "LifeSteal",
    price: 220,
    features: ["8GB RAM", "LifeSteal Mechanics", "40 Player Slots", "Custom Plugins"],
    popular: false
  },
  {
    name: "BoxPVP",
    price: 300,
    features: ["10GB RAM", "PVP Arenas", "50 Player Slots", "Custom Kits"],
    popular: false
  },
  {
    name: "SkyBlock",
    price: 450,
    features: ["12GB RAM", "SkyBlock Islands", "60 Player Slots", "Economy System"],
    popular: false
  },
  {
    name: "All Gamemodes",
    price: 750,
    features: ["16GB RAM", "All Game Modes Included", "100 Player Slots", "Priority Support"],
    popular: true
  }
];

// Resource Categories
export const resourceCategories = [
  { id: "all", name: "All Resources" },
  { id: "guide", name: "Guides" },
  { id: "template", name: "Templates" },
  { id: "setup", name: "Setup" },
  { id: "editing", name: "Editing" },
  { id: "coding", name: "Coding" },
  { id: "business", name: "Business" }
];
