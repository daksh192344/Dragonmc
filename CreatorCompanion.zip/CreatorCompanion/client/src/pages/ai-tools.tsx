import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Task, FitnessRecommendation, BusinessIdea, LearningResource } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import {
  Clock,
  BookOpen,
  Activity,
  Brain,
  Lightbulb,
  MessageSquare,
  Send,
  CheckCircle2,
  PlusCircle,
  Trash2,
} from "lucide-react";

// Task form schema
const taskFormSchema = z.object({
  title: z.string().min(3, { message: "Task must be at least 3 characters" }),
  dueDate: z.string().optional(),
  priority: z.enum(["low", "medium", "high"]),
});

// AI message schema for chat
const aiMessageSchema = z.object({
  message: z.string().min(1, { message: "Message cannot be empty" }),
});

export default function AITools() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Default userId - would typically come from authentication
  const userId = 1;
  
  // States for AI chat
  const [chatMessages, setChatMessages] = useState([
    { role: "assistant", content: "Hi there! I'm your Gemini AI assistant powered by Google's advanced language model. How can I help you with your content creation today?" }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  
  // Fetch data
  const { data: tasks, isLoading: loadingTasks } = useQuery<Task[]>({
    queryKey: [`/api/tasks/user/${userId}`],
  });
  
  const { data: fitnessRecommendations, isLoading: loadingFitness } = useQuery<FitnessRecommendation[]>({
    queryKey: ['/api/fitness-recommendations'],
  });
  
  const { data: businessIdeas, isLoading: loadingBusinessIdeas } = useQuery<BusinessIdea[]>({
    queryKey: ['/api/business-ideas'],
  });
  
  const { data: learningResources, isLoading: loadingLearning } = useQuery<LearningResource[]>({
    queryKey: ['/api/learning-resources'],
  });
  
  // Task mutations
  const createTaskMutation = useMutation({
    mutationFn: (newTask: Omit<Task, 'id'>) => 
      apiRequest("POST", "/api/tasks", newTask),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/tasks/user/${userId}`] });
      toast({
        title: "Task Created",
        description: "Your task has been added successfully."
      });
      taskForm.reset({
        title: "",
        dueDate: "",
        priority: "medium"
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create task",
        variant: "destructive"
      });
    }
  });
  
  const updateTaskMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<Task> }) => 
      apiRequest("PATCH", `/api/tasks/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/tasks/user/${userId}`] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update task",
        variant: "destructive"
      });
    }
  });
  
  const deleteTaskMutation = useMutation({
    mutationFn: (id: number) => 
      apiRequest("DELETE", `/api/tasks/${id}`, undefined),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/tasks/user/${userId}`] });
      toast({
        title: "Task Deleted",
        description: "Task has been removed successfully."
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete task",
        variant: "destructive"
      });
    }
  });
  
  // Learning resource progress mutation
  const updateProgressMutation = useMutation({
    mutationFn: ({ id, progress }: { id: number; progress: number }) => 
      apiRequest("PATCH", `/api/learning-resources/${id}/progress`, { progress }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/learning-resources'] });
      toast({
        title: "Progress Updated",
        description: "Your learning progress has been updated."
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update progress",
        variant: "destructive"
      });
    }
  });
  
  // AI idea generation
  const generateIdeasMutation = useMutation({
    mutationFn: (topic: string) => 
      apiRequest("POST", "/api/ai/generate-ideas", { topic }),
    onSuccess: (data) => {
      toast({
        title: "Ideas Generated",
        description: "New content ideas have been generated for you."
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to generate ideas",
        variant: "destructive"
      });
    }
  });
  
  // AI Message handler
  const sendMessage = async (message: string) => {
    if (!message.trim()) return;
    
    // Add user message to chat
    setChatMessages(prev => [...prev, { role: "user", content: message }]);
    setIsTyping(true);
    
    try {
      // Mock AI response - in a real app, you'd call your OpenAI API endpoint
      // This simulates an API call with a timeout
      setTimeout(() => {
        let responseMessage = "I'm sorry, I don't have enough information to help with that specific request. Could you provide more details?";
        
        // Very simple keyword matching for demo purposes
        if (message.toLowerCase().includes("idea") || message.toLowerCase().includes("content")) {
          responseMessage = "Here are some content ideas you might consider:\n1. 'Day in the Life' vlog showing your content creation process\n2. Tutorial on your Minecraft server setup\n3. Q&A session answering viewer questions\n4. Collaboration with another creator in your niche";
        } else if (message.toLowerCase().includes("sponsor") || message.toLowerCase().includes("brand")) {
          responseMessage = "When reaching out to potential sponsors, be sure to:\n1. Highlight your audience demographics\n2. Show examples of previous sponsored content\n3. Clearly articulate your pricing structure\n4. Explain why your audience would be interested in their product";
        } else if (message.toLowerCase().includes("schedule") || message.toLowerCase().includes("plan")) {
          responseMessage = "For effective content scheduling, try:\n1. Batching similar types of content on the same day\n2. Planning your content calendar at least 2 weeks in advance\n3. Leaving flexibility for trending topics\n4. Setting aside specific times for filming, editing, and engagement";
        }
        
        setChatMessages(prev => [...prev, { role: "assistant", content: responseMessage }]);
        setIsTyping(false);
      }, 1500);
      
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to get a response from the AI. Please try again.",
        variant: "destructive"
      });
      setIsTyping(false);
    }
  };
  
  // Task form setup
  const taskForm = useForm<z.infer<typeof taskFormSchema>>({
    resolver: zodResolver(taskFormSchema),
    defaultValues: {
      title: "",
      dueDate: "",
      priority: "medium"
    }
  });
  
  // Chat form setup
  const chatForm = useForm<z.infer<typeof aiMessageSchema>>({
    resolver: zodResolver(aiMessageSchema),
    defaultValues: {
      message: ""
    }
  });
  
  const onTaskSubmit = (data: z.infer<typeof taskFormSchema>) => {
    createTaskMutation.mutate({
      userId,
      title: data.title,
      priority: data.priority,
      dueDate: data.dueDate ? new Date(data.dueDate) : undefined,
      completed: false
    });
  };
  
  const onChatSubmit = (data: z.infer<typeof aiMessageSchema>) => {
    sendMessage(data.message);
    chatForm.reset({ message: "" });
  };
  
  // Toggle task completion
  const toggleTaskCompletion = (task: Task) => {
    updateTaskMutation.mutate({
      id: task.id,
      data: { completed: !task.completed }
    });
  };
  
  // Handle task deletion
  const handleDeleteTask = (taskId: number) => {
    deleteTaskMutation.mutate(taskId);
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">
          <span className="bg-gradient-to-r from-blue-600 to-teal-500 text-transparent bg-clip-text">Gemini AI</span> Tools
        </h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Supercharge your productivity and content creation with our suite of Gemini-powered AI assistants.
          These tools help you manage tasks, stay healthy, learn new skills, and generate ideas using Google's powerful Gemini AI technology.
        </p>
      </div>
      
      <Tabs defaultValue="tasks" className="max-w-5xl mx-auto">
        <TabsList className="grid grid-cols-2 md:grid-cols-5 w-full mb-8">
          <TabsTrigger value="tasks" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            <span className="hidden md:inline">Task Assistant</span>
          </TabsTrigger>
          <TabsTrigger value="fitness" className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            <span className="hidden md:inline">Fitness</span>
          </TabsTrigger>
          <TabsTrigger value="learning" className="flex items-center gap-2">
            <BookOpen className="h-4 w-4" />
            <span className="hidden md:inline">Learning</span>
          </TabsTrigger>
          <TabsTrigger value="ideas" className="flex items-center gap-2">
            <Lightbulb className="h-4 w-4" />
            <span className="hidden md:inline">Ideas</span>
          </TabsTrigger>
          <TabsTrigger value="assistant" className="flex items-center gap-2">
            <MessageSquare className="h-4 w-4" />
            <span className="hidden md:inline">Gemini Chat</span>
          </TabsTrigger>
        </TabsList>
        
        {/* Task Assistant */}
        <TabsContent value="tasks">
          <div className="grid md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Task Manager</CardTitle>
                <CardDescription>Keep track of your content creation tasks and deadlines</CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...taskForm}>
                  <form onSubmit={taskForm.handleSubmit(onTaskSubmit)} className="space-y-4">
                    <FormField
                      control={taskForm.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Task</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter a new task..." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={taskForm.control}
                        name="dueDate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Due Date (Optional)</FormLabel>
                            <FormControl>
                              <Input type="date" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={taskForm.control}
                        name="priority"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Priority</FormLabel>
                            <FormControl>
                              <select
                                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                                {...field}
                              >
                                <option value="low">Low</option>
                                <option value="medium">Medium</option>
                                <option value="high">High</option>
                              </select>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Button type="submit" className="w-full">
                      <PlusCircle className="mr-2 h-4 w-4" />
                      Add Task
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Today's Tasks</CardTitle>
                <CardDescription>
                  {loadingTasks 
                    ? "Loading your tasks..." 
                    : tasks && tasks.length > 0 
                      ? `You have ${tasks.filter(t => !t.completed).length} pending tasks` 
                      : "No tasks yet, add some to stay organized"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {loadingTasks ? (
                  <div className="space-y-3">
                    {Array(4).fill(0).map((_, i) => (
                      <div key={i} className="flex items-center animate-pulse">
                        <div className="w-5 h-5 rounded-sm bg-gray-200 mr-3"></div>
                        <div className="h-5 bg-gray-200 rounded w-full"></div>
                      </div>
                    ))}
                  </div>
                ) : tasks && tasks.length > 0 ? (
                  <ul className="space-y-3">
                    {tasks.map(task => (
                      <li key={task.id} className="flex items-center justify-between group">
                        <div className="flex items-center">
                          <Checkbox 
                            id={`task-${task.id}`} 
                            checked={task.completed}
                            onCheckedChange={() => toggleTaskCompletion(task)}
                            className="mr-3"
                          />
                          <Label 
                            htmlFor={`task-${task.id}`}
                            className={`text-sm ${task.completed ? 'line-through text-gray-500' : ''}`}
                          >
                            {task.title}
                            {task.priority === "high" && (
                              <span className="ml-2 px-1.5 py-0.5 text-xs rounded-full bg-red-100 text-red-700">
                                High
                              </span>
                            )}
                            {task.dueDate && (
                              <span className="ml-2 text-xs text-gray-500">
                                {new Date(task.dueDate).toLocaleDateString()}
                              </span>
                            )}
                          </Label>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8"
                          onClick={() => handleDeleteTask(task.id)}
                        >
                          <Trash2 className="h-4 w-4 text-gray-500" />
                        </Button>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="text-center py-6">
                    <Clock className="mx-auto h-12 w-12 text-gray-300 mb-2" />
                    <p className="text-gray-500">No tasks yet. Add some to get organized!</p>
                  </div>
                )}
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button variant="outline" size="sm">View All Tasks</Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        
        {/* Fitness Recommendations */}
        <TabsContent value="fitness">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Fitness Recommendations</CardTitle>
                  <CardDescription>Stay healthy with personalized exercises for content creators</CardDescription>
                </div>
                <Activity className="h-8 w-8 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <h3 className="font-medium text-gray-900 mb-4">Today's Recommendations</h3>
              {loadingFitness ? (
                <div className="space-y-4">
                  {Array(3).fill(0).map((_, i) => (
                    <div key={i} className="flex items-start animate-pulse">
                      <div className="w-5 h-5 rounded-full bg-gray-200 mt-1 mr-3"></div>
                      <div>
                        <div className="h-5 bg-gray-200 rounded w-32 mb-2"></div>
                        <div className="h-4 bg-gray-200 rounded w-48"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : fitnessRecommendations && fitnessRecommendations.length > 0 ? (
                <ul className="space-y-4">
                  {fitnessRecommendations.map(rec => (
                    <li key={rec.id} className="flex items-start">
                      <CheckCircle2 className="text-green-500 mt-1 mr-3 h-5 w-5 flex-shrink-0" />
                      <div>
                        <span className="font-medium text-gray-900">{rec.title}</span>
                        <p className="text-sm text-gray-600">{rec.description}</p>
                        <div className="mt-1 text-xs text-gray-500 flex items-center">
                          <Clock className="mr-1 h-3 w-3" />
                          <span>{rec.duration} minutes</span>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="text-center py-6">
                  <Activity className="mx-auto h-12 w-12 text-gray-300 mb-2" />
                  <p className="text-gray-500">No fitness recommendations available right now.</p>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button className="w-full">Get Personalized Plan</Button>
            </CardFooter>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Screen Break Reminder</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">Follow the 20-20-20 rule: Every 20 minutes, look at something 20 feet away for 20 seconds.</p>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-500">Next break in:</span>
                  <span className="font-medium">14:32</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
                  <div className="bg-primary h-2.5 rounded-full" style={{ width: '27%' }}></div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline">Skip</Button>
                <Button variant="outline">Take Break Now</Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Hydration Tracker</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">Staying hydrated improves focus and energy levels during content creation.</p>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-500">Today's intake:</span>
                  <span className="font-medium">4/8 glasses</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
                  <div className="bg-blue-500 h-2.5 rounded-full" style={{ width: '50%' }}></div>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full">Log Water Intake</Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        
        {/* Learning Assistant */}
        <TabsContent value="learning">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Learning Path</CardTitle>
                  <CardDescription>Personalized tutorials and learning resources for content creators</CardDescription>
                </div>
                <BookOpen className="h-8 w-8 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <h3 className="font-medium text-gray-900 mb-4">Your Learning Progress</h3>
              {loadingLearning ? (
                <div className="space-y-6">
                  {Array(3).fill(0).map((_, i) => (
                    <div key={i} className="animate-pulse">
                      <div className="flex justify-between mb-1">
                        <div className="h-5 bg-gray-200 rounded w-40"></div>
                        <div className="h-5 bg-gray-200 rounded w-20"></div>
                      </div>
                      <div className="w-full h-2.5 bg-gray-200 rounded-full"></div>
                    </div>
                  ))}
                </div>
              ) : learningResources && learningResources.length > 0 ? (
                <div className="space-y-6">
                  {learningResources.map(resource => (
                    <div key={resource.id}>
                      <div className="flex justify-between mb-1">
                        <span className="font-medium text-sm">{resource.title}</span>
                        <span className="text-xs text-gray-500">{resource.progress}% Complete</span>
                      </div>
                      <div className="w-full h-2.5 bg-gray-200 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-primary rounded-full" 
                          style={{ width: `${resource.progress}%` }}
                        ></div>
                      </div>
                      <div className="flex justify-end mt-1">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-6 text-xs"
                          onClick={() => updateProgressMutation.mutate({
                            id: resource.id, 
                            progress: Math.min(100, resource.progress + 10)
                          })}
                        >
                          Update Progress
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6">
                  <BookOpen className="mx-auto h-12 w-12 text-gray-300 mb-2" />
                  <p className="text-gray-500">No learning resources available right now.</p>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button className="w-full">Explore More Courses</Button>
            </CardFooter>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Recommended Tutorials</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="text-sm">
                    <a href="#" className="text-primary hover:underline flex items-center">
                      <BookOpen className="h-3 w-3 mr-2" />
                      Advanced Thumbnail Design
                    </a>
                  </li>
                  <li className="text-sm">
                    <a href="#" className="text-primary hover:underline flex items-center">
                      <BookOpen className="h-3 w-3 mr-2" />
                      Lighting for YouTube Videos
                    </a>
                  </li>
                  <li className="text-sm">
                    <a href="#" className="text-primary hover:underline flex items-center">
                      <BookOpen className="h-3 w-3 mr-2" />
                      Audio Mixing Fundamentals
                    </a>
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button variant="ghost" size="sm" className="w-full">
                  View All
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Live Workshops</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <h4 className="font-medium text-sm">Creator SEO Masterclass</h4>
                    <p className="text-xs text-gray-500">Tomorrow, 3:00 PM</p>
                  </div>
                  <div>
                    <h4 className="font-medium text-sm">Editing for Viral Content</h4>
                    <p className="text-xs text-gray-500">Friday, 1:00 PM</p>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="ghost" size="sm" className="w-full">
                  View Schedule
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Creator Community</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-3">
                  Connect with other creators to share knowledge and collaborate.
                </p>
                <div className="flex -space-x-2">
                  <div className="w-8 h-8 rounded-full bg-gray-300"></div>
                  <div className="w-8 h-8 rounded-full bg-blue-300"></div>
                  <div className="w-8 h-8 rounded-full bg-green-300"></div>
                  <div className="w-8 h-8 rounded-full bg-yellow-300"></div>
                  <div className="w-8 h-8 rounded-full bg-purple-300 flex items-center justify-center text-xs text-white">+24</div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="ghost" size="sm" className="w-full">
                  Join Community
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        
        {/* Business Ideas */}
        <TabsContent value="ideas">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Business & Content Ideas</CardTitle>
                  <CardDescription>Get personalized business ideas based on your channel and skills</CardDescription>
                </div>
                <Lightbulb className="h-8 w-8 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <Label htmlFor="topic" className="mb-2 block">Generate ideas for:</Label>
                <div className="flex gap-2">
                  <Input 
                    id="topic" 
                    placeholder="e.g. Minecraft tutorials, gaming channel monetization"
                    className="flex-grow"
                  />
                  <Button onClick={() => generateIdeasMutation.mutate("minecraft content")}>
                    Generate
                  </Button>
                </div>
              </div>
              
              <h3 className="font-medium text-gray-900 mb-4">Ideas For You</h3>
              {loadingBusinessIdeas ? (
                <div className="space-y-4">
                  {Array(3).fill(0).map((_, i) => (
                    <div key={i} className="flex items-start animate-pulse">
                      <div className="w-5 h-5 rounded-full bg-gray-200 mt-1 mr-3"></div>
                      <div>
                        <div className="h-5 bg-gray-200 rounded w-40 mb-2"></div>
                        <div className="h-4 bg-gray-200 rounded w-full"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : businessIdeas && businessIdeas.length > 0 ? (
                <ul className="space-y-4">
                  {businessIdeas.map(idea => (
                    <li key={idea.id} className="flex items-start">
                      <div className="text-amber-500 mt-1 mr-3 h-5 w-5 flex-shrink-0">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M12 2L15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2z" />
                        </svg>
                      </div>
                      <div>
                        <span className="font-medium text-gray-900">{idea.title}</span>
                        <p className="text-sm text-gray-600">{idea.description}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="text-center py-6">
                  <Lightbulb className="mx-auto h-12 w-12 text-gray-300 mb-2" />
                  <p className="text-gray-500">No business ideas available right now. Try generating some!</p>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button className="w-full">Save Ideas to My List</Button>
            </CardFooter>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Content Trend Analysis</CardTitle>
                <CardDescription>See what's trending in your niche</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="flex justify-between items-center">
                    <span className="text-sm">Minecraft Challenges</span>
                    <span className="text-xs px-2 py-1 bg-green-100 text-green-800 rounded-full">+24%</span>
                  </li>
                  <li className="flex justify-between items-center">
                    <span className="text-sm">Server Tours</span>
                    <span className="text-xs px-2 py-1 bg-green-100 text-green-800 rounded-full">+15%</span>
                  </li>
                  <li className="flex justify-between items-center">
                    <span className="text-sm">Redstone Tutorials</span>
                    <span className="text-xs px-2 py-1 bg-amber-100 text-amber-800 rounded-full">+5%</span>
                  </li>
                  <li className="flex justify-between items-center">
                    <span className="text-sm">PvP Battles</span>
                    <span className="text-xs px-2 py-1 bg-red-100 text-red-800 rounded-full">-8%</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">View Full Analysis</Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Monetization Strategies</CardTitle>
                <CardDescription>Ways to diversify your revenue streams</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <div className="bg-primary-100 text-primary p-1 rounded mr-3 mt-0.5">
                      <svg className="h-3 w-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <polygon points="10 8 16 12 10 16 10 8"></polygon>
                      </svg>
                    </div>
                    <div>
                      <span className="text-sm font-medium">Membership Program</span>
                      <p className="text-xs text-gray-500">Offer exclusive content to members</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-primary-100 text-primary p-1 rounded mr-3 mt-0.5">
                      <svg className="h-3 w-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                        <polyline points="7 10 12 15 17 10"></polyline>
                        <line x1="12" y1="15" x2="12" y2="3"></line>
                      </svg>
                    </div>
                    <div>
                      <span className="text-sm font-medium">Digital Products</span>
                      <p className="text-xs text-gray-500">Sell resource packs, maps, or tutorials</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-primary-100 text-primary p-1 rounded mr-3 mt-0.5">
                      <svg className="h-3 w-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect>
                        <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path>
                      </svg>
                    </div>
                    <div>
                      <span className="text-sm font-medium">Merchandise</span>
                      <p className="text-xs text-gray-500">Create branded apparel and accessories</p>
                    </div>
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">Explore Strategies</Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        
        {/* AI Chat Assistant */}
        <TabsContent value="assistant">
          <Card className="mb-8">
            <CardHeader className="border-b bg-gradient-to-r from-blue-600 to-teal-500 text-white">
              <CardTitle className="flex items-center">
                <span className="mr-2">Gemini AI Assistant</span>
                <span className="text-xs bg-white text-blue-600 px-2 py-0.5 rounded-full">Powered by Google</span>
              </CardTitle>
              <CardDescription className="text-primary-100">
                Ask me anything about content creation, channel growth, or Minecraft
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="h-96 overflow-y-auto p-4 flex flex-col space-y-4">
                {chatMessages.map((message, index) => (
                  <div key={index} className={`flex items-start ${message.role === 'assistant' ? '' : 'justify-end'}`}>
                    {message.role === 'assistant' && (
                      <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-600 to-teal-500 text-white flex items-center justify-center mr-2 flex-shrink-0">
                        <MessageSquare className="h-4 w-4" />
                      </div>
                    )}
                    <div 
                      className={`p-3 rounded-lg shadow-sm max-w-xs md:max-w-md whitespace-pre-line ${
                        message.role === 'assistant' 
                          ? 'bg-white' 
                          : 'bg-primary-100'
                      }`}
                    >
                      <p className="text-sm">{message.content}</p>
                    </div>
                    {message.role === 'user' && (
                      <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center ml-2 flex-shrink-0">
                        <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                          <circle cx="12" cy="7" r="4"></circle>
                        </svg>
                      </div>
                    )}
                  </div>
                ))}
                {isTyping && (
                  <div className="flex items-start">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-600 to-teal-500 text-white flex items-center justify-center mr-2 flex-shrink-0">
                      <MessageSquare className="h-4 w-4" />
                    </div>
                    <div className="p-3 rounded-lg shadow-sm bg-white">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce delay-75"></div>
                        <div className="w-2 h-2 bg-teal-500 rounded-full animate-bounce delay-150"></div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter className="p-4 border-t">
              <Form {...chatForm}>
                <form onSubmit={chatForm.handleSubmit(onChatSubmit)} className="flex w-full">
                  <FormField
                    control={chatForm.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem className="flex-grow">
                        <FormControl>
                          <Input 
                            placeholder="Ask Gemini AI a question..." 
                            className="rounded-r-none focus:ring-0 border-blue-200" 
                            {...field} 
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <Button type="submit" className="rounded-l-none bg-gradient-to-r from-blue-600 to-teal-500">
                    <Send className="h-4 w-4" />
                  </Button>
                </form>
              </Form>
            </CardFooter>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Suggested Prompts</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li>
                    <Button 
                      variant="ghost" 
                      className="text-left h-auto py-1 justify-start text-sm w-full"
                      onClick={() => sendMessage("What are some trending Minecraft video ideas?")}
                    >
                      What are some trending Minecraft video ideas?
                    </Button>
                  </li>
                  <li>
                    <Button 
                      variant="ghost" 
                      className="text-left h-auto py-1 justify-start text-sm w-full"
                      onClick={() => sendMessage("How can I optimize my videos for YouTube search?")}
                    >
                      How can I optimize my videos for YouTube search?
                    </Button>
                  </li>
                  <li>
                    <Button 
                      variant="ghost" 
                      className="text-left h-auto py-1 justify-start text-sm w-full"
                      onClick={() => sendMessage("What's a good content schedule for a growing channel?")}
                    >
                      What's a good content schedule for a growing channel?
                    </Button>
                  </li>
                </ul>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Voice Assistance</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <Button variant="outline" className="w-full bg-gradient-to-r from-blue-600/10 to-teal-500/10 border-blue-200">
                  <svg className="mr-2 h-4 w-4 text-blue-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path>
                    <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
                    <line x1="12" y1="19" x2="12" y2="23"></line>
                    <line x1="8" y1="23" x2="16" y2="23"></line>
                  </svg>
                  Speak to Gemini
                </Button>
                <p className="text-xs text-gray-500 mt-2">
                  Use voice commands to interact with your Gemini AI Assistant
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Chat History</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center justify-between">
                    <span className="text-gray-600 truncate">Video Optimization Tips</span>
                    <span className="text-xs text-gray-400">Today</span>
                  </li>
                  <li className="flex items-center justify-between">
                    <span className="text-gray-600 truncate">Minecraft Plugin Recommendations</span>
                    <span className="text-xs text-gray-400">Yesterday</span>
                  </li>
                  <li className="flex items-center justify-between">
                    <span className="text-gray-600 truncate">Channel Growth Strategy</span>
                    <span className="text-xs text-gray-400">3 days ago</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button variant="ghost" size="sm" className="w-full text-xs">
                  View All History
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
