import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { CreatorResource } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DownloadIcon, ArrowRightIcon } from "lucide-react";

export default function CreatorResources() {
  const [activeCategory, setActiveCategory] = useState("all");
  
  const { data: resources, isLoading } = useQuery<CreatorResource[]>({
    queryKey: ['/api/creator-resources'],
  });
  
  const categories = [
    { id: "all", name: "All Resources" },
    { id: "guide", name: "Guides" },
    { id: "template", name: "Templates" },
    { id: "setup", name: "Setup" },
    { id: "editing", name: "Editing" },
    { id: "coding", name: "Coding" },
    { id: "business", name: "Business" }
  ];
  
  const filteredResources = resources?.filter(resource => 
    activeCategory === "all" || resource.category === activeCategory
  );
  
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Creator Resources</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Everything you need to create viral content, improve your editing skills, and grow your channel.
          Access free guides, templates, and tools designed specifically for content creators.
        </p>
      </div>
      
      <Tabs defaultValue="all" onValueChange={setActiveCategory} className="mb-8">
        <TabsList className="flex flex-wrap justify-center gap-2 mb-8">
          {categories.map(category => (
            <TabsTrigger key={category.id} value={category.id} className="rounded-full px-4">
              {category.name}
            </TabsTrigger>
          ))}
        </TabsList>
        
        {categories.map(category => (
          <TabsContent key={category.id} value={category.id}>
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {Array(6).fill(0).map((_, index) => (
                  <div key={index} className="bg-white rounded-xl shadow-md p-6 animate-pulse">
                    <div className="h-48 bg-gray-200 rounded-lg mb-4"></div>
                    <div className="h-6 bg-gray-200 rounded w-3/4 mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-full mb-4"></div>
                    <div className="flex justify-between">
                      <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                      <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredResources?.map(resource => (
                  <div key={resource.id} className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow">
                    <div className="h-48 bg-gray-200 relative">
                      {resource.thumbnail && (
                        <img 
                          src={resource.thumbnail} 
                          alt={resource.title} 
                          className="w-full h-full object-cover"
                        />
                      )}
                      <div className="absolute top-0 left-0 bg-primary text-white px-3 py-1 text-sm font-medium">
                        {resource.category.charAt(0).toUpperCase() + resource.category.slice(1)}
                      </div>
                    </div>
                    <div className="p-6">
                      <h3 className="text-xl font-bold text-gray-900 mb-2">{resource.title}</h3>
                      <p className="text-gray-600 mb-4">{resource.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-500">{resource.details}</span>
                        <Button variant="link" className="text-primary hover:text-primary-700 font-medium flex items-center">
                          {resource.downloadUrl ? "Download" : "View Guide"}
                          {resource.downloadUrl ? (
                            <DownloadIcon className="ml-1 h-4 w-4" />
                          ) : (
                            <ArrowRightIcon className="ml-1 h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
        ))}
      </Tabs>
      
      <div className="mt-16 bg-primary-50 rounded-xl p-8">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold mb-2">Request Custom Resources</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Need something specific for your content creation? Let us know what resources would help you grow your channel.
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
          <input 
            type="email" 
            placeholder="Your email" 
            className="flex-grow px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
          />
          <Button>Request Resource</Button>
        </div>
      </div>
      
      <div className="mt-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Join Creator Community</h2>
        <p className="text-gray-600 max-w-2xl mx-auto mb-6">
          Connect with other content creators, share tips, and get feedback on your content in our community.
        </p>
        <Button size="lg" variant="outline">Join Discord Community</Button>
      </div>
    </div>
  );
}
