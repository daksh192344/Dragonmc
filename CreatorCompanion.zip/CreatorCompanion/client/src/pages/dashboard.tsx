import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Task, 
  MinecraftServer, 
  CreatorResource,
  BusinessIdea,
  FitnessRecommendation,
  LearningResource
} from "@shared/schema";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription, 
  CardFooter 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SidebarNav } from "@/components/ui/sidebar-nav";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Link } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import {
  Clock,
  CheckCircle2,
  ArrowRight,
  LayoutGrid,
  BarChart,
  UserCircle,
  Settings,
  Calendar,
  Activity,
  Lightbulb,
  BookOpen,
  MessageSquare,
  PlusCircle,
  ChevronRight,
  ChevronUp,
  Check
} from "lucide-react";

// Mock user data (would typically come from auth context)
const user = {
  id: 1,
  username: "CreatorUser",
  email: "creator@example.com",
  isCreator: true
};

export default function Dashboard() {
  const { toast } = useToast();
  const [selectedTab, setSelectedTab] = useState("overview");
  
  // Fetch user data
  const { data: tasks, isLoading: loadingTasks } = useQuery<Task[]>({
    queryKey: [`/api/tasks/user/${user.id}`],
    staleTime: 30000,
  });
  
  const { data: resources, isLoading: loadingResources } = useQuery<CreatorResource[]>({
    queryKey: ['/api/creator-resources'],
    staleTime: 60000,
  });
  
  const { data: fitnessRecommendations, isLoading: loadingFitness } = useQuery<FitnessRecommendation[]>({
    queryKey: ['/api/fitness-recommendations'],
    staleTime: 60000,
  });
  
  const { data: businessIdeas, isLoading: loadingBusinessIdeas } = useQuery<BusinessIdea[]>({
    queryKey: ['/api/business-ideas'],
    staleTime: 60000,
  });
  
  const { data: learningResources, isLoading: loadingLearning } = useQuery<LearningResource[]>({
    queryKey: ['/api/learning-resources'],
    staleTime: 60000,
  });
  
  // Task completion mutation
  const toggleTaskMutation = useMutation({
    mutationFn: ({ id, completed }: { id: number; completed: boolean }) => 
      apiRequest("PATCH", `/api/tasks/${id}`, { completed }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/tasks/user/${user.id}`] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update task status",
        variant: "destructive"
      });
    }
  });
  
  // Handle task toggle
  const handleTaskToggle = (task: Task) => {
    toggleTaskMutation.mutate({
      id: task.id,
      completed: !task.completed
    });
  };
  
  // Get pending tasks count
  const pendingTasksCount = tasks?.filter(task => !task.completed).length || 0;
  
  // Navigation items
  const sidebarNavItems = [
    {
      title: "Overview",
      href: "#overview",
      icon: <LayoutGrid className="h-4 w-4" />,
    },
    {
      title: "Analytics",
      href: "#analytics",
      icon: <BarChart className="h-4 w-4" />,
    },
    {
      title: "Calendar",
      href: "#calendar",
      icon: <Calendar className="h-4 w-4" />,
    },
    {
      title: "Profile",
      href: "/profile",
      icon: <UserCircle className="h-4 w-4" />,
    },
    {
      title: "Settings",
      href: "#settings",
      icon: <Settings className="h-4 w-4" />,
    },
  ];
  
  // Resources for quick access
  const featuredResources = resources?.slice(0, 3) || [];

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <div className="hidden md:flex w-64 flex-col bg-gray-900 text-white">
        <div className="p-6">
          <h2 className="text-xl font-bold mb-1">Creator<span className="text-primary-500">Hub</span></h2>
          <p className="text-sm text-gray-400">Dashboard</p>
        </div>
        
        <nav className="flex-1 px-4 py-2 space-y-8">
          <div>
            <h3 className="text-xs uppercase text-gray-500 font-semibold px-2 mb-2">Main</h3>
            <ul className="space-y-1">
              {sidebarNavItems.map((item) => (
                <li key={item.title}>
                  <a 
                    href={item.href} 
                    className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
                      selectedTab === item.title.toLowerCase() 
                        ? 'bg-primary text-white' 
                        : 'text-gray-300 hover:text-white hover:bg-gray-800'
                    }`}
                    onClick={() => item.href.startsWith('#') && setSelectedTab(item.title.toLowerCase())}
                  >
                    {item.icon}
                    {item.title}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-xs uppercase text-gray-500 font-semibold px-2 mb-2">Tools</h3>
            <ul className="space-y-1">
              <li>
                <Link href="/ai-tools">
                  <a className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-gray-300 hover:text-white hover:bg-gray-800 transition-colors">
                    <MessageSquare className="h-4 w-4" />
                    AI Assistant
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/minecraft-servers">
                  <a className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-gray-300 hover:text-white hover:bg-gray-800 transition-colors">
                    <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"></rect>
                      <line x1="7" y1="2" x2="7" y2="22"></line>
                      <line x1="17" y1="2" x2="17" y2="22"></line>
                      <line x1="2" y1="12" x2="22" y2="12"></line>
                      <line x1="2" y1="7" x2="7" y2="7"></line>
                      <line x1="2" y1="17" x2="7" y2="17"></line>
                      <line x1="17" y1="17" x2="22" y2="17"></line>
                      <line x1="17" y1="7" x2="22" y2="7"></line>
                    </svg>
                    Minecraft Servers
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/sponsorships">
                  <a className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-gray-300 hover:text-white hover:bg-gray-800 transition-colors">
                    <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"></path>
                    </svg>
                    Sponsorships
                  </a>
                </Link>
              </li>
            </ul>
          </div>
        </nav>
        
        <div className="p-4 border-t border-gray-800">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-primary flex-shrink-0 flex items-center justify-center text-white">
              {user.username.charAt(0).toUpperCase()}
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium">{user.username}</p>
              <p className="text-xs text-gray-400 truncate">{user.email}</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Main content */}
      <div className="flex-1 bg-gray-50">
        <header className="bg-white shadow">
          <div className="px-6 py-4 flex items-center justify-between">
            <h1 className="text-xl font-semibold text-gray-900">Dashboard</h1>
            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm">
                <Calendar className="h-4 w-4 mr-2" />
                <span>Today</span>
              </Button>
              <Link href="/ai-tools">
                <Button size="sm">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  <span>AI Assistant</span>
                </Button>
              </Link>
            </div>
          </div>
        </header>
        
        <main className="p-6">
          {/* Overview Section */}
          {selectedTab === "overview" && (
            <div className="space-y-6">
              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-500">Pending Tasks</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center">
                      <div className="text-2xl font-bold">
                        {loadingTasks ? "..." : pendingTasksCount}
                      </div>
                      <div className="ml-2 flex-shrink-0">
                        <Badge variant={pendingTasksCount > 5 ? "destructive" : "default"} className="rounded-full">
                          {pendingTasksCount > 5 ? "High" : "Normal"}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-500">Learning Progress</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center">
                      <div className="text-2xl font-bold">42%</div>
                      <div className="ml-2 text-green-500 text-sm flex items-center">
                        <ChevronUp className="h-4 w-4" />
                        <span>5%</span>
                      </div>
                    </div>
                    <Progress value={42} className="h-1.5 mt-2" />
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-500">Next Stream</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">2d 14h</div>
                    <div className="text-sm text-gray-500 mt-1">Friday, 3:00 PM</div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-500">Fitness Score</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center">
                      <div className="text-2xl font-bold">76/100</div>
                      <div className="ml-2 text-green-500 text-sm flex items-center">
                        <ChevronUp className="h-4 w-4" />
                        <span>12</span>
                      </div>
                    </div>
                    <Progress value={76} className="h-1.5 mt-2" />
                  </CardContent>
                </Card>
              </div>
              
              {/* Task Manager and Fitness sections */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="lg:col-span-2">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle>Task Manager</CardTitle>
                      <Link href="/ai-tools">
                        <Button variant="outline" size="sm">
                          <PlusCircle className="h-4 w-4 mr-2" />
                          <span>Add Task</span>
                        </Button>
                      </Link>
                    </div>
                    <CardDescription>Manage your content creation workflow</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {loadingTasks ? (
                      <div className="space-y-3">
                        {Array(5).fill(0).map((_, i) => (
                          <div key={i} className="flex items-center animate-pulse">
                            <div className="w-4 h-4 rounded-sm bg-gray-200 mr-3"></div>
                            <div className="h-5 bg-gray-200 rounded w-full"></div>
                          </div>
                        ))}
                      </div>
                    ) : tasks && tasks.length > 0 ? (
                      <ul className="space-y-2">
                        {tasks.slice(0, 5).map(task => (
                          <li key={task.id} className="flex items-center justify-between py-1 group">
                            <div className="flex items-center">
                              <Checkbox 
                                id={`dash-task-${task.id}`} 
                                checked={task.completed}
                                onCheckedChange={() => handleTaskToggle(task)}
                                className="mr-3"
                              />
                              <label 
                                htmlFor={`dash-task-${task.id}`}
                                className={`text-sm ${task.completed ? 'line-through text-gray-500' : 'text-gray-900'}`}
                              >
                                {task.title}
                                {task.priority === "high" && (
                                  <Badge variant="destructive" className="ml-2 py-0 px-1.5 h-4">High</Badge>
                                )}
                              </label>
                            </div>
                            {task.dueDate && (
                              <span className="text-xs text-gray-500">
                                {new Date(task.dueDate).toLocaleDateString()}
                              </span>
                            )}
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <div className="text-center py-6">
                        <Clock className="mx-auto h-12 w-12 text-gray-300 mb-2" />
                        <p className="text-gray-500">No tasks yet. Add some to get organized!</p>
                      </div>
                    )}
                  </CardContent>
                  <CardFooter className="flex justify-between border-t pt-4">
                    <div className="text-xs text-gray-500">
                      {tasks ? `${tasks.filter(t => t.completed).length}/${tasks.length} tasks completed` : 'No tasks'}
                    </div>
                    <Link href="/ai-tools?tab=tasks">
                      <Button variant="ghost" size="sm">
                        View All
                        <ChevronRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle>Fitness Reminder</CardTitle>
                    <CardDescription>Take breaks to stay healthy</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {loadingFitness ? (
                      <div className="space-y-4">
                        {Array(2).fill(0).map((_, i) => (
                          <div key={i} className="flex items-start animate-pulse">
                            <div className="w-5 h-5 rounded-full bg-gray-200 mt-1 mr-3"></div>
                            <div>
                              <div className="h-5 bg-gray-200 rounded w-32 mb-2"></div>
                              <div className="h-4 bg-gray-200 rounded w-48"></div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : fitnessRecommendations?.slice(0, 2).map(rec => (
                      <div key={rec.id} className="flex items-start mb-4">
                        <CheckCircle2 className="text-green-500 mt-1 mr-3 h-5 w-5 flex-shrink-0" />
                        <div>
                          <h4 className="font-medium text-gray-900">{rec.title}</h4>
                          <p className="text-sm text-gray-600">{rec.description}</p>
                          <div className="mt-1 text-xs text-gray-500 flex items-center">
                            <Clock className="mr-1 h-3 w-3" />
                            <span>{rec.duration} minutes</span>
                          </div>
                        </div>
                      </div>
                    ))}
                    
                    <div className="mt-2">
                      <h4 className="font-medium text-gray-900 mb-2">Screen Break Timer</h4>
                      <div className="flex justify-between items-center mb-1.5">
                        <span className="text-xs text-gray-500">Next break in:</span>
                        <span className="text-xs font-medium">12:45</span>
                      </div>
                      <Progress value={35} className="h-1.5" />
                    </div>
                  </CardContent>
                  <CardFooter className="border-t pt-4">
                    <Link href="/ai-tools?tab=fitness">
                      <Button variant="outline" size="sm" className="w-full">
                        View Fitness Plan
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </div>
              
              {/* Learning Progress and Resource sections */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle>Learning Progress</CardTitle>
                    <CardDescription>Track your skill development</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {loadingLearning ? (
                      <div className="space-y-6">
                        {Array(3).fill(0).map((_, i) => (
                          <div key={i} className="animate-pulse">
                            <div className="flex justify-between mb-1">
                              <div className="h-5 bg-gray-200 rounded w-40"></div>
                              <div className="h-5 bg-gray-200 rounded w-20"></div>
                            </div>
                            <div className="w-full h-2.5 bg-gray-200 rounded-full"></div>
                          </div>
                        ))}
                      </div>
                    ) : learningResources?.slice(0, 3).map(resource => (
                      <div key={resource.id} className="mb-4">
                        <div className="flex justify-between mb-1">
                          <span className="font-medium text-sm">{resource.title}</span>
                          <span className="text-xs text-gray-500">{resource.progress}% Complete</span>
                        </div>
                        <Progress 
                          value={resource.progress} 
                          className="h-2" 
                        />
                      </div>
                    ))}
                  </CardContent>
                  <CardFooter className="border-t pt-4">
                    <Link href="/ai-tools?tab=learning">
                      <Button variant="outline" size="sm" className="w-full">
                        Continue Learning
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                
                <Card className="lg:col-span-2">
                  <CardHeader className="pb-3">
                    <CardTitle>Creator Resources</CardTitle>
                    <CardDescription>Quick access to helpful materials</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {loadingResources ? (
                        Array(3).fill(0).map((_, i) => (
                          <div key={i} className="rounded-lg border border-gray-200 p-4 animate-pulse">
                            <div className="w-8 h-8 rounded-full bg-gray-200 mb-3"></div>
                            <div className="h-5 w-24 bg-gray-200 rounded mb-2"></div>
                            <div className="h-4 w-full bg-gray-200 rounded mb-2"></div>
                            <div className="h-4 w-3/4 bg-gray-200 rounded"></div>
                          </div>
                        ))
                      ) : featuredResources.map(resource => (
                        <div key={resource.id} className="rounded-lg border border-gray-200 p-4">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                            resource.category === 'guide' ? 'bg-blue-100 text-blue-700' :
                            resource.category === 'template' ? 'bg-amber-100 text-amber-700' :
                            'bg-green-100 text-green-700'
                          } mb-3`}>
                            {resource.category === 'guide' ? (
                              <BookOpen className="h-4 w-4" />
                            ) : resource.category === 'template' ? (
                              <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                <line x1="9" y1="3" x2="9" y2="21"></line>
                              </svg>
                            ) : (
                              <Lightbulb className="h-4 w-4" />
                            )}
                          </div>
                          <h3 className="font-medium text-gray-900 mb-1">{resource.title}</h3>
                          <p className="text-sm text-gray-500 mb-2 line-clamp-2">{resource.description}</p>
                          <Link href={`/creator-resources?id=${resource.id}`}>
                            <Button variant="link" className="p-0 h-auto text-primary text-sm">
                              View Details
                            </Button>
                          </Link>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                  <CardFooter className="border-t pt-4">
                    <Link href="/creator-resources">
                      <Button variant="outline" size="sm" className="w-full">
                        Browse All Resources
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </div>
              
              {/* Business Ideas and Sponsorship Opportunity */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle>Business Ideas</CardTitle>
                    <CardDescription>Revenue opportunities for your channel</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {loadingBusinessIdeas ? (
                      <div className="space-y-4">
                        {Array(3).fill(0).map((_, i) => (
                          <div key={i} className="flex items-start animate-pulse">
                            <div className="w-5 h-5 rounded-full bg-gray-200 mt-1 mr-3"></div>
                            <div>
                              <div className="h-5 bg-gray-200 rounded w-40 mb-2"></div>
                              <div className="h-4 bg-gray-200 rounded w-full"></div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : businessIdeas?.slice(0, 3).map(idea => (
                      <div key={idea.id} className="flex items-start mb-4">
                        <div className="text-amber-500 mt-1 mr-3 h-5 w-5 flex-shrink-0">
                          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M12 2L15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2z" />
                          </svg>
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-900">{idea.title}</h4>
                          <p className="text-sm text-gray-600">{idea.description}</p>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                  <CardFooter className="border-t pt-4">
                    <Link href="/ai-tools?tab=ideas">
                      <Button variant="outline" size="sm" className="w-full">
                        Generate More Ideas
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle>Sponsorship Opportunities</CardTitle>
                    <CardDescription>Connect with brands and monetize your content</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="rounded-lg border border-dashed border-gray-300 p-6 text-center">
                      <div className="mx-auto w-12 h-12 rounded-full bg-primary-50 flex items-center justify-center mb-3">
                        <svg className="h-6 w-6 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                          <circle cx="9" cy="7" r="4"></circle>
                          <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"></path>
                        </svg>
                      </div>
                      <h3 className="font-medium text-gray-900 mb-1">Complete Your Creator Profile</h3>
                      <p className="text-sm text-gray-500 mb-4">
                        Set up your channel details to match with potential sponsors
                      </p>
                      <Link href="/sponsorships?tab=profile">
                        <Button>Complete Profile</Button>
                      </Link>
                    </div>
                  </CardContent>
                  <CardFooter className="border-t pt-4">
                    <Link href="/sponsorships">
                      <Button variant="outline" size="sm" className="w-full">
                        Browse Sponsorships
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </div>
            </div>
          )}
          
          {/* Other tabs would be implemented here */}
          {selectedTab === "analytics" && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Analytics</h2>
              <p className="text-gray-500">Channel analytics dashboard coming soon...</p>
            </div>
          )}
          
          {selectedTab === "calendar" && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Content Calendar</h2>
              <p className="text-gray-500">Content planning calendar coming soon...</p>
            </div>
          )}
          
          {selectedTab === "settings" && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Account Settings</h2>
              <p className="text-gray-500">Account settings page coming soon...</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
