import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Link } from "wouter";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { User, CreatorProfile, SponsorProfile } from "@shared/schema";

// Mock user data (would normally come from auth context)
const mockUser: User = {
  id: 1,
  username: "CreatorUser",
  email: "creator@example.com",
  password: "", // Password would never be exposed on the frontend
  isCreator: true,
  isSponsor: false,
};

// Profile schema for form validation
const profileSchema = z.object({
  username: z.string().min(3, { message: "Username must be at least 3 characters" }),
  email: z.string().email({ message: "Please enter a valid email" }),
  currentPassword: z.string().optional(),
  newPassword: z.string().min(6, { message: "New password must be at least 6 characters" }).optional(),
  confirmPassword: z.string().optional(),
}).refine(data => {
  if (data.newPassword && !data.currentPassword) {
    return false;
  }
  return true;
}, {
  message: "Current password is required to set a new password",
  path: ["currentPassword"],
}).refine(data => {
  if (data.newPassword && data.confirmPassword && data.newPassword !== data.confirmPassword) {
    return false;
  }
  return true;
}, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

// Creator profile schema
const creatorProfileSchema = z.object({
  channelName: z.string().min(3, { message: "Channel name must be at least 3 characters" }),
  channelUrl: z.string().url({ message: "Please enter a valid URL" }).optional().or(z.literal('')),
  subscribers: z.number().min(0),
  niche: z.string().min(3, { message: "Niche must be at least 3 characters" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters" }),
  minBudget: z.number().min(0),
});

// Sponsor profile schema
const sponsorProfileSchema = z.object({
  companyName: z.string().min(3, { message: "Company name must be at least 3 characters" }),
  website: z.string().url({ message: "Please enter a valid URL" }).optional().or(z.literal('')),
  industry: z.string().min(3, { message: "Industry must be at least 3 characters" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters" }),
  budget: z.number().min(0),
});

export default function Profile() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("account");

  // Fetch user profile data
  const { data: user, isLoading: loadingUser } = useQuery<User>({
    queryKey: ['/api/user/profile'],
    // This would typically get the current user's profile
    // but for now we'll use the mock data since the backend is not fully connected
    initialData: mockUser,
  });

  // Fetch creator profile if user is a creator
  const { data: creatorProfile, isLoading: loadingCreatorProfile } = useQuery<CreatorProfile>({
    queryKey: [`/api/creator-profiles/user/${user?.id}`],
    enabled: !!user?.id && (user?.isCreator ?? false),
  });

  // Fetch sponsor profile if user is a sponsor
  const { data: sponsorProfile, isLoading: loadingSponsorProfile } = useQuery<SponsorProfile>({
    queryKey: [`/api/sponsor-profiles/user/${user?.id}`],
    enabled: !!user?.id && (user?.isSponsor ?? false),
  });

  // Form setup for account settings
  const accountForm = useForm<z.infer<typeof profileSchema>>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      username: user?.username || "",
      email: user?.email || "",
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  });

  // Form setup for creator profile
  const creatorForm = useForm<z.infer<typeof creatorProfileSchema>>({
    resolver: zodResolver(creatorProfileSchema),
    defaultValues: {
      channelName: creatorProfile?.channelName || "",
      channelUrl: creatorProfile?.channelUrl || "",
      subscribers: creatorProfile?.subscribers || 0,
      niche: creatorProfile?.niche || "",
      description: creatorProfile?.description || "",
      minBudget: creatorProfile?.minBudget || 0,
    },
  });

  // Form setup for sponsor profile
  const sponsorForm = useForm<z.infer<typeof sponsorProfileSchema>>({
    resolver: zodResolver(sponsorProfileSchema),
    defaultValues: {
      companyName: sponsorProfile?.companyName || "",
      website: sponsorProfile?.website || "",
      industry: sponsorProfile?.industry || "",
      description: sponsorProfile?.description || "",
      budget: sponsorProfile?.budget || 0,
    },
  });

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: (data: z.infer<typeof profileSchema>) => 
      apiRequest("PATCH", "/api/user/profile", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
      toast({
        title: "Profile Updated",
        description: "Your account settings have been updated successfully."
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update profile",
        variant: "destructive"
      });
    }
  });

  // Update creator profile mutation
  const updateCreatorProfileMutation = useMutation({
    mutationFn: (data: z.infer<typeof creatorProfileSchema>) => 
      creatorProfile 
        ? apiRequest("PATCH", `/api/creator-profiles/${creatorProfile.id}`, data)
        : apiRequest("POST", "/api/creator-profiles", { ...data, userId: user?.id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/creator-profiles/user/${user?.id}`] });
      toast({
        title: "Creator Profile Updated",
        description: "Your creator profile has been updated successfully."
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update creator profile",
        variant: "destructive"
      });
    }
  });

  // Update sponsor profile mutation
  const updateSponsorProfileMutation = useMutation({
    mutationFn: (data: z.infer<typeof sponsorProfileSchema>) => 
      sponsorProfile 
        ? apiRequest("PATCH", `/api/sponsor-profiles/${sponsorProfile.id}`, data)
        : apiRequest("POST", "/api/sponsor-profiles", { ...data, userId: user?.id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/sponsor-profiles/user/${user?.id}`] });
      toast({
        title: "Sponsor Profile Updated",
        description: "Your sponsor profile has been updated successfully."
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update sponsor profile",
        variant: "destructive"
      });
    }
  });

  // Handler for account form submission
  const onAccountSubmit = (data: z.infer<typeof profileSchema>) => {
    updateProfileMutation.mutate(data);
  };

  // Handler for creator profile form submission
  const onCreatorSubmit = (data: z.infer<typeof creatorProfileSchema>) => {
    updateCreatorProfileMutation.mutate(data);
  };

  // Handler for sponsor profile form submission
  const onSponsorSubmit = (data: z.infer<typeof sponsorProfileSchema>) => {
    updateSponsorProfileMutation.mutate(data);
  };

  // Update forms when data is loaded
  React.useEffect(() => {
    if (user) {
      accountForm.reset({
        username: user.username,
        email: user.email,
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
    }
  }, [user, accountForm]);

  React.useEffect(() => {
    if (creatorProfile) {
      creatorForm.reset({
        channelName: creatorProfile.channelName,
        channelUrl: creatorProfile.channelUrl || "",
        subscribers: creatorProfile.subscribers,
        niche: creatorProfile.niche || "",
        description: creatorProfile.description || "",
        minBudget: creatorProfile.minBudget,
      });
    }
  }, [creatorProfile, creatorForm]);

  React.useEffect(() => {
    if (sponsorProfile) {
      sponsorForm.reset({
        companyName: sponsorProfile.companyName,
        website: sponsorProfile.website || "",
        industry: sponsorProfile.industry || "",
        description: sponsorProfile.description || "",
        budget: sponsorProfile.budget,
      });
    }
  }, [sponsorProfile, sponsorForm]);

  return (
    <div className="container max-w-5xl mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row items-start gap-8">
        {/* Profile sidebar */}
        <div className="w-full md:w-64 mb-8 md:mb-0">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center">
                <Avatar className="h-24 w-24 mb-4">
                  <AvatarImage src="" alt={user?.username} />
                  <AvatarFallback className="text-xl">
                    {user?.username?.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <h2 className="text-xl font-bold mb-1">{user?.username}</h2>
                <p className="text-sm text-gray-500 mb-4">{user?.email}</p>
                <div className="flex gap-2 mb-4">
                  {user?.isCreator && (
                    <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">
                      Creator
                    </span>
                  )}
                  {user?.isSponsor && (
                    <span className="px-2 py-1 bg-amber-100 text-amber-800 text-xs rounded-full">
                      Sponsor
                    </span>
                  )}
                </div>
                <Link href="/dashboard">
                  <Button variant="outline" className="w-full">
                    Dashboard
                  </Button>
                </Link>
              </div>
              
              <Separator className="my-6" />
              
              <div className="space-y-1">
                <button
                  onClick={() => setActiveTab("account")}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm ${
                    activeTab === "account" 
                      ? "bg-primary text-white" 
                      : "hover:bg-gray-100"
                  }`}
                >
                  Account Settings
                </button>
                
                {user?.isCreator && (
                  <button
                    onClick={() => setActiveTab("creator")}
                    className={`w-full text-left px-3 py-2 rounded-lg text-sm ${
                      activeTab === "creator" 
                        ? "bg-primary text-white" 
                        : "hover:bg-gray-100"
                    }`}
                  >
                    Creator Profile
                  </button>
                )}
                
                {user?.isSponsor && (
                  <button
                    onClick={() => setActiveTab("sponsor")}
                    className={`w-full text-left px-3 py-2 rounded-lg text-sm ${
                      activeTab === "sponsor" 
                        ? "bg-primary text-white" 
                        : "hover:bg-gray-100"
                    }`}
                  >
                    Sponsor Profile
                  </button>
                )}
                
                <button
                  onClick={() => setActiveTab("preferences")}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm ${
                    activeTab === "preferences" 
                      ? "bg-primary text-white" 
                      : "hover:bg-gray-100"
                  }`}
                >
                  Preferences
                </button>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Main content area */}
        <div className="flex-1">
          {activeTab === "account" && (
            <Card>
              <CardHeader>
                <CardTitle>Account Settings</CardTitle>
                <CardDescription>
                  Update your account information and password
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...accountForm}>
                  <form onSubmit={accountForm.handleSubmit(onAccountSubmit)} className="space-y-6">
                    <FormField
                      control={accountForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={accountForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Separator />
                    
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Change Password</h3>
                      
                      <FormField
                        control={accountForm.control}
                        name="currentPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Current Password</FormLabel>
                            <FormControl>
                              <Input type="password" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={accountForm.control}
                          name="newPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>New Password</FormLabel>
                              <FormControl>
                                <Input type="password" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={accountForm.control}
                          name="confirmPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Confirm New Password</FormLabel>
                              <FormControl>
                                <Input type="password" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <Button type="submit" className="w-full">
                      Save Changes
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          )}
          
          {activeTab === "creator" && (
            <Card>
              <CardHeader>
                <CardTitle>Creator Profile</CardTitle>
                <CardDescription>
                  Manage your creator profile to help sponsors find you
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...creatorForm}>
                  <form onSubmit={creatorForm.handleSubmit(onCreatorSubmit)} className="space-y-6">
                    <FormField
                      control={creatorForm.control}
                      name="channelName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Channel Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Your channel name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={creatorForm.control}
                      name="channelUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Channel URL</FormLabel>
                          <FormControl>
                            <Input placeholder="https://youtube.com/c/yourchannel" {...field} />
                          </FormControl>
                          <FormDescription>
                            Link to your YouTube channel or website
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={creatorForm.control}
                        name="subscribers"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Subscriber Count</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="0" 
                                {...field}
                                onChange={e => field.onChange(parseInt(e.target.value) || 0)}
                                value={field.value}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={creatorForm.control}
                        name="minBudget"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Minimum Budget (₹)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="0" 
                                {...field}
                                onChange={e => field.onChange(parseInt(e.target.value) || 0)}
                                value={field.value}
                              />
                            </FormControl>
                            <FormDescription>
                              What's your minimum sponsorship fee?
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={creatorForm.control}
                      name="niche"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Content Niche</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Gaming, Lifestyle, Tech" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={creatorForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Channel Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe your channel, content style, and audience"
                              className="min-h-[120px]" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full">
                      {creatorProfile ? "Update Profile" : "Create Profile"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          )}
          
          {activeTab === "sponsor" && (
            <Card>
              <CardHeader>
                <CardTitle>Sponsor Profile</CardTitle>
                <CardDescription>
                  Manage your sponsor profile to connect with content creators
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...sponsorForm}>
                  <form onSubmit={sponsorForm.handleSubmit(onSponsorSubmit)} className="space-y-6">
                    <FormField
                      control={sponsorForm.control}
                      name="companyName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company/Brand Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Your company name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={sponsorForm.control}
                      name="website"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Website</FormLabel>
                          <FormControl>
                            <Input placeholder="https://yourcompany.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={sponsorForm.control}
                        name="industry"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Industry</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. Gaming, Technology, Lifestyle" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={sponsorForm.control}
                        name="budget"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Sponsorship Budget (₹)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="0" 
                                {...field}
                                onChange={e => field.onChange(parseInt(e.target.value) || 0)}
                                value={field.value}
                              />
                            </FormControl>
                            <FormDescription>
                              What's your total budget for campaigns?
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={sponsorForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company/Campaign Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe your brand, products, and the type of creators you're looking for"
                              className="min-h-[120px]" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full">
                      {sponsorProfile ? "Update Profile" : "Create Profile"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          )}
          
          {activeTab === "preferences" && (
            <Card>
              <CardHeader>
                <CardTitle>Preferences</CardTitle>
                <CardDescription>
                  Customize your experience and notification settings
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500 text-center py-8">
                  Preference settings coming soon...
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
