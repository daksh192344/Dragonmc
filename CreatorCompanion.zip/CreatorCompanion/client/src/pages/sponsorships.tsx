import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { CreatorProfile, SponsorProfile } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { CheckIcon, UserIcon, BuildingIcon, ArrowRightIcon, SearchIcon } from "lucide-react";

const creatorProfileSchema = z.object({
  userId: z.number(),
  channelName: z.string().min(3, { message: "Channel name must be at least 3 characters" }),
  channelUrl: z.string().url({ message: "Please enter a valid URL" }).optional().or(z.literal('')),
  subscribers: z.number().min(0),
  niche: z.string().min(3, { message: "Niche must be at least 3 characters" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters" }),
  minBudget: z.number().min(0)
});

const sponsorProfileSchema = z.object({
  userId: z.number(),
  companyName: z.string().min(3, { message: "Company name must be at least 3 characters" }),
  website: z.string().url({ message: "Please enter a valid URL" }).optional().or(z.literal('')),
  industry: z.string().min(3, { message: "Industry must be at least 3 characters" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters" }),
  budget: z.number().min(0)
});

export default function Sponsorships() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("find");
  
  // Extract type from URL query parameter if present
  const params = new URLSearchParams(location.split("?")[1]);
  const initialType = params.get("type") === "sponsor" ? "sponsor" : "creator";
  const [userType, setUserType] = useState(initialType);
  
  // Search states
  const [budgetRange, setBudgetRange] = useState([0, 1000]);
  const [searchQuery, setSearchQuery] = useState("");
  
  // Get creators for sponsors
  const { data: creators, isLoading: loadingCreators } = useQuery<CreatorProfile[]>({
    queryKey: [`/api/match/creators?budget=${budgetRange[1]}`],
    enabled: userType === "sponsor" && activeTab === "find"
  });
  
  // Get sponsors for creators
  const { data: sponsors, isLoading: loadingSponsors } = useQuery<SponsorProfile[]>({
    queryKey: [`/api/match/sponsors?minBudget=${budgetRange[0]}`],
    enabled: userType === "creator" && activeTab === "find"
  });
  
  // Forms setup
  const creatorForm = useForm<z.infer<typeof creatorProfileSchema>>({
    resolver: zodResolver(creatorProfileSchema),
    defaultValues: {
      userId: 1, // This would normally come from auth context
      channelName: "",
      channelUrl: "",
      subscribers: 0,
      niche: "",
      description: "",
      minBudget: 0
    }
  });
  
  const sponsorForm = useForm<z.infer<typeof sponsorProfileSchema>>({
    resolver: zodResolver(sponsorProfileSchema),
    defaultValues: {
      userId: 1, // This would normally come from auth context
      companyName: "",
      website: "",
      industry: "",
      description: "",
      budget: 0
    }
  });
  
  const onCreatorSubmit = async (data: z.infer<typeof creatorProfileSchema>) => {
    try {
      await apiRequest("POST", "/api/creator-profiles", data);
      toast({
        title: "Profile Created",
        description: "Your creator profile has been created successfully!"
      });
      setActiveTab("find");
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create profile",
        variant: "destructive"
      });
    }
  };
  
  const onSponsorSubmit = async (data: z.infer<typeof sponsorProfileSchema>) => {
    try {
      await apiRequest("POST", "/api/sponsor-profiles", data);
      toast({
        title: "Profile Created",
        description: "Your sponsor profile has been created successfully!"
      });
      setActiveTab("find");
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create profile",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Connect with Sponsors & Creators</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Find the perfect sponsorship match for your channel, or connect with creators as a brand.
          Our platform makes it easy to build mutually beneficial partnerships.
        </p>
      </div>
      
      <div className="mb-12">
        <h2 className="text-2xl font-bold text-center mb-6">I am a...</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* Creator Card */}
          <Card 
            className={`cursor-pointer transition-all hover:shadow-lg ${userType === "creator" ? "ring-2 ring-primary" : ""}`}
            onClick={() => setUserType("creator")}
          >
            <CardHeader>
              <div className="flex items-center justify-center mb-4">
                <UserIcon size={40} className="text-primary" />
              </div>
              <CardTitle className="text-center">Content Creator</CardTitle>
              <CardDescription className="text-center">
                I create content and want to find sponsorships
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <CheckIcon className="text-green-500 h-5 w-5 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Get matched with brands based on your niche</span>
                </li>
                <li className="flex items-start">
                  <CheckIcon className="text-green-500 h-5 w-5 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Negotiate sponsorship deals that match your worth</span>
                </li>
                <li className="flex items-start">
                  <CheckIcon className="text-green-500 h-5 w-5 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Access promotional tools and resources</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button 
                variant={userType === "creator" ? "default" : "outline"} 
                className="w-full"
                onClick={() => setUserType("creator")}
              >
                I'm a Creator
              </Button>
            </CardFooter>
          </Card>
          
          {/* Sponsor Card */}
          <Card 
            className={`cursor-pointer transition-all hover:shadow-lg ${userType === "sponsor" ? "ring-2 ring-primary" : ""}`}
            onClick={() => setUserType("sponsor")}
          >
            <CardHeader>
              <div className="flex items-center justify-center mb-4">
                <BuildingIcon size={40} className="text-primary" />
              </div>
              <CardTitle className="text-center">Brand/Sponsor</CardTitle>
              <CardDescription className="text-center">
                I represent a brand looking for content creators
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <CheckIcon className="text-green-500 h-5 w-5 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Find creators that match your target audience</span>
                </li>
                <li className="flex items-start">
                  <CheckIcon className="text-green-500 h-5 w-5 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Set your budget and campaign requirements</span>
                </li>
                <li className="flex items-start">
                  <CheckIcon className="text-green-500 h-5 w-5 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Track campaign performance metrics</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button 
                variant={userType === "sponsor" ? "default" : "outline"} 
                className="w-full"
                onClick={() => setUserType("sponsor")}
              >
                I'm a Sponsor
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="max-w-4xl mx-auto">
        <TabsList className="grid grid-cols-2 w-full mb-8">
          <TabsTrigger value="find">Find Matches</TabsTrigger>
          <TabsTrigger value="profile">Create Profile</TabsTrigger>
        </TabsList>
        
        <TabsContent value="find">
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Find {userType === "creator" ? "Sponsors" : "Creators"}</CardTitle>
              <CardDescription>
                {userType === "creator" 
                  ? "Search for brands and sponsors that match your audience and content type." 
                  : "Search for content creators that align with your brand and campaign goals."}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-grow relative">
                    <SearchIcon className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input 
                      type="text" 
                      placeholder={`Search by ${userType === "creator" ? "industry or company" : "niche or channel"}`}
                      className="pl-9"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <Button>Search</Button>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">Budget Range</span>
                    <span className="text-sm">₹{budgetRange[0]} - ₹{budgetRange[1]}</span>
                  </div>
                  <Slider
                    defaultValue={[0, 1000]}
                    min={0}
                    max={2000}
                    step={50}
                    value={budgetRange}
                    onValueChange={setBudgetRange}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {userType === "creator" ? (
              loadingSponsors ? (
                Array(6).fill(0).map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader>
                      <div className="h-6 w-2/3 bg-gray-200 rounded mb-2"></div>
                      <div className="h-4 w-1/2 bg-gray-200 rounded"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="h-20 bg-gray-200 rounded mb-4"></div>
                      <div className="h-4 w-1/3 bg-gray-200 rounded mb-2"></div>
                      <div className="h-4 w-1/4 bg-gray-200 rounded"></div>
                    </CardContent>
                  </Card>
                ))
              ) : sponsors && sponsors.length > 0 ? (
                sponsors.map((sponsor) => (
                  <Card key={sponsor.id}>
                    <CardHeader>
                      <CardTitle>{sponsor.companyName}</CardTitle>
                      <CardDescription>{sponsor.industry}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-sm text-gray-600">{sponsor.description}</p>
                      <div className="flex justify-between text-sm">
                        <span className="font-medium">Budget:</span>
                        <span>₹{sponsor.budget}</span>
                      </div>
                      {sponsor.website && (
                        <div className="flex justify-between text-sm">
                          <span className="font-medium">Website:</span>
                          <a href={sponsor.website} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                            Visit Site
                          </a>
                        </div>
                      )}
                    </CardContent>
                    <CardFooter>
                      <Button className="w-full">Contact Sponsor</Button>
                    </CardFooter>
                  </Card>
                ))
              ) : (
                <div className="col-span-3 text-center py-12">
                  <h3 className="text-lg font-medium mb-2">No sponsors found</h3>
                  <p className="text-gray-500 mb-6">Try adjusting your search criteria or check back later.</p>
                  <Button onClick={() => setActiveTab("profile")}>Create Your Profile First</Button>
                </div>
              )
            ) : (
              // For sponsors looking for creators
              loadingCreators ? (
                Array(6).fill(0).map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader>
                      <div className="h-6 w-2/3 bg-gray-200 rounded mb-2"></div>
                      <div className="h-4 w-1/2 bg-gray-200 rounded"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="h-20 bg-gray-200 rounded mb-4"></div>
                      <div className="h-4 w-1/3 bg-gray-200 rounded mb-2"></div>
                      <div className="h-4 w-1/4 bg-gray-200 rounded"></div>
                    </CardContent>
                  </Card>
                ))
              ) : creators && creators.length > 0 ? (
                creators.map((creator) => (
                  <Card key={creator.id}>
                    <CardHeader>
                      <CardTitle>{creator.channelName}</CardTitle>
                      <CardDescription>{creator.niche}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-sm text-gray-600">{creator.description}</p>
                      <div className="flex justify-between text-sm">
                        <span className="font-medium">Subscribers:</span>
                        <span>{creator.subscribers.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="font-medium">Min Budget:</span>
                        <span>₹{creator.minBudget}</span>
                      </div>
                      {creator.channelUrl && (
                        <div className="flex justify-between text-sm">
                          <span className="font-medium">Channel:</span>
                          <a href={creator.channelUrl} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                            Visit Channel
                          </a>
                        </div>
                      )}
                    </CardContent>
                    <CardFooter>
                      <Button className="w-full">Contact Creator</Button>
                    </CardFooter>
                  </Card>
                ))
              ) : (
                <div className="col-span-3 text-center py-12">
                  <h3 className="text-lg font-medium mb-2">No creators found</h3>
                  <p className="text-gray-500 mb-6">Try adjusting your search criteria or check back later.</p>
                  <Button onClick={() => setActiveTab("profile")}>Create Your Profile First</Button>
                </div>
              )
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>Create Your {userType === "creator" ? "Creator" : "Sponsor"} Profile</CardTitle>
              <CardDescription>
                {userType === "creator" 
                  ? "Complete your creator profile to help sponsors find you" 
                  : "Set up your sponsor profile to connect with the right creators"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {userType === "creator" ? (
                <Form {...creatorForm}>
                  <form onSubmit={creatorForm.handleSubmit(onCreatorSubmit)} className="space-y-6">
                    <FormField
                      control={creatorForm.control}
                      name="channelName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Channel Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Your channel name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={creatorForm.control}
                      name="channelUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Channel URL</FormLabel>
                          <FormControl>
                            <Input placeholder="https://youtube.com/c/yourchannel" {...field} />
                          </FormControl>
                          <FormDescription>
                            Link to your YouTube channel or website
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={creatorForm.control}
                      name="subscribers"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Subscriber Count</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              placeholder="0" 
                              {...field}
                              onChange={e => field.onChange(parseInt(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={creatorForm.control}
                      name="niche"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Content Niche</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Gaming, Lifestyle, Tech" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={creatorForm.control}
                      name="minBudget"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Minimum Budget (₹)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              placeholder="0" 
                              {...field}
                              onChange={e => field.onChange(parseInt(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormDescription>
                            What's your minimum sponsorship fee?
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={creatorForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Channel Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe your channel, content style, and audience"
                              className="min-h-[120px]" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full">
                      Create Creator Profile
                    </Button>
                  </form>
                </Form>
              ) : (
                <Form {...sponsorForm}>
                  <form onSubmit={sponsorForm.handleSubmit(onSponsorSubmit)} className="space-y-6">
                    <FormField
                      control={sponsorForm.control}
                      name="companyName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company/Brand Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Your company name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={sponsorForm.control}
                      name="website"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Website</FormLabel>
                          <FormControl>
                            <Input placeholder="https://yourcompany.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={sponsorForm.control}
                      name="industry"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Industry</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Gaming, Technology, Lifestyle" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={sponsorForm.control}
                      name="budget"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Sponsorship Budget (₹)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              placeholder="0" 
                              {...field}
                              onChange={e => field.onChange(parseInt(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormDescription>
                            What's your total budget for campaigns?
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={sponsorForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company/Campaign Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe your brand, products, and the type of creators you're looking for"
                              className="min-h-[120px]" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full">
                      Create Sponsor Profile
                    </Button>
                  </form>
                </Form>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="mt-16">
        <h3 className="text-2xl font-bold text-center mb-8">How It Works</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <div className="text-center">
            <div className="w-16 h-16 bg-primary-100 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-xl font-bold">1</span>
            </div>
            <h4 className="text-lg font-bold text-gray-900 mb-2">Create Profile</h4>
            <p className="text-gray-600">Build your creator or sponsor profile with relevant information about your channel or brand.</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-primary-100 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-xl font-bold">2</span>
            </div>
            <h4 className="text-lg font-bold text-gray-900 mb-2">Get Matched</h4>
            <p className="text-gray-600">Our AI matching system connects you with the most compatible partners based on your criteria.</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-primary-100 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-xl font-bold">3</span>
            </div>
            <h4 className="text-lg font-bold text-gray-900 mb-2">Collaborate</h4>
            <p className="text-gray-600">Negotiate terms, create content, and track performance all through our platform.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
