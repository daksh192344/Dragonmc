import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { MinecraftServer, CreatorResource } from "@shared/schema";
import { CheckIcon, ArrowRightIcon } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";

export default function Home() {
  const { data: minecraftServers, isLoading: loadingServers } = useQuery<MinecraftServer[]>({
    queryKey: ['/api/minecraft-servers'],
  });

  const { data: creatorResources, isLoading: loadingResources } = useQuery<CreatorResource[]>({
    queryKey: ['/api/creator-resources'],
  });

  // Only show a subset of servers on homepage
  const featuredServers = minecraftServers?.slice(0, 4);
  const featuredResources = creatorResources?.slice(0, 3);

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary-700 to-primary-900 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-3xl md:text-5xl font-bold mb-6">Your Complete Creator Success Platform</h1>
            <p className="text-lg md:text-xl mb-8 opacity-90">Everything you need to grow your content creation business - from Minecraft servers to sponsorship deals, all in one place.</p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link href="/sponsorships">
                <Button size="lg" className="px-6 py-3 bg-amber-500 text-black hover:bg-amber-600">
                  Find Sponsorships
                </Button>
              </Link>
              <Link href="/ai-tools">
                <Button size="lg" variant="outline" className="px-6 py-3 bg-white text-primary-800 hover:bg-gray-100 border-0">
                  Explore Tools
                </Button>
              </Link>
            </div>
          </div>
        </div>
        <div className="h-16 md:h-24 bg-white"></div>
      </section>

      {/* Minecraft Server Preview Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Minecraft Server Solutions</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Launch your perfect Minecraft server with our pre-configured game modes at affordable prices.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {loadingServers ? (
              Array(4).fill(0).map((_, index) => (
                <div key={index} className="rounded-xl border border-gray-200 bg-white shadow-md p-6 animate-pulse">
                  <div className="h-40 bg-gray-200 rounded-lg mb-4"></div>
                  <div className="h-6 bg-gray-200 rounded w-1/2 mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                  <div className="h-10 bg-gray-200 rounded-lg"></div>
                </div>
              ))
            ) : (
              featuredServers?.map((server) => (
                <div key={server.id} className="pricing-card rounded-xl overflow-hidden border border-gray-200 bg-white shadow-md transition-transform hover:-translate-y-1 hover:shadow-lg">
                  <div className="h-40 bg-primary-600 relative flex items-center justify-center">
                    {server.popular && (
                      <div className="absolute top-3 right-3 bg-amber-500 text-black text-xs font-bold px-2 py-1 rounded-full">
                        BEST VALUE
                      </div>
                    )}
                    <h3 className="text-2xl font-bold text-white relative z-10">{server.name}</h3>
                  </div>
                  <div className="p-6">
                    <div className="flex justify-center mb-4">
                      <span className="text-3xl font-bold text-gray-900">₹{server.price}<span className="text-lg font-normal text-gray-500">/mo</span></span>
                    </div>
                    <ul className="mb-6 space-y-2">
                      {server.features?.map((feature, index) => (
                        <li key={index} className="flex items-center text-sm text-gray-600">
                          <CheckIcon className="text-green-500 mr-2 h-4 w-4" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Button className="w-full" variant={server.popular ? "default" : "secondary"}>
                      Get Started
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
          
          <div className="mt-10 text-center">
            <Link href="/minecraft-servers" className="inline-flex items-center text-primary hover:text-primary-700 font-medium">
              View all server options
              <ArrowRightIcon className="ml-1 h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Resources Preview */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Creator Resources</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Everything you need to create viral content, improve your editing, and grow your channel.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {loadingResources ? (
              Array(3).fill(0).map((_, index) => (
                <div key={index} className="bg-white rounded-xl shadow-md p-6 animate-pulse">
                  <div className="h-48 bg-gray-200 rounded-lg mb-4"></div>
                  <div className="h-6 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-full mb-4"></div>
                  <div className="flex justify-between">
                    <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                  </div>
                </div>
              ))
            ) : (
              featuredResources?.map((resource) => (
                <div key={resource.id} className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow">
                  <div className="h-48 bg-gray-200 relative">
                    {resource.thumbnail && (
                      <img 
                        src={resource.thumbnail} 
                        alt={resource.title} 
                        className="w-full h-full object-cover"
                      />
                    )}
                    <div className="absolute top-0 left-0 bg-primary text-white px-3 py-1 text-sm font-medium">
                      {resource.category.charAt(0).toUpperCase() + resource.category.slice(1)}
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{resource.title}</h3>
                    <p className="text-gray-600 mb-4">{resource.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">{resource.details}</span>
                      <Button variant="link" className="text-primary hover:text-primary-700 font-medium flex items-center">
                        {resource.downloadUrl ? "Download" : "View"}
                        {resource.downloadUrl ? (
                          <svg className="ml-1 h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                          </svg>
                        ) : (
                          <ArrowRightIcon className="ml-1 h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
          
          <div className="mt-10 text-center">
            <Link href="/creator-resources" className="inline-flex items-center text-primary hover:text-primary-700 font-medium">
              Explore all resources
              <ArrowRightIcon className="ml-1 h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Sponsorship Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Connect with Sponsors</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Find the perfect sponsorship match for your channel, or connect with creators as a brand.</p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Creator Card */}
            <div className="bg-gradient-to-br from-primary-600 to-primary-800 rounded-xl overflow-hidden shadow-lg p-8 text-white">
              <div className="flex items-center justify-center mb-6">
                <svg className="h-16 w-16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 15C15.3137 15 18 12.3137 18 9C18 5.68629 15.3137 3 12 3C8.68629 3 6 5.68629 6 9C6 12.3137 8.68629 15 12 15Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M12 15V21M8 21H16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-center mb-6">I'm a Creator</h3>
              <ul className="space-y-4 mb-8">
                <li className="flex items-start">
                  <CheckIcon className="text-amber-400 h-5 w-5 mt-1 mr-3" />
                  <span>Get matched with brands based on your channel's niche and audience</span>
                </li>
                <li className="flex items-start">
                  <CheckIcon className="text-amber-400 h-5 w-5 mt-1 mr-3" />
                  <span>Negotiate sponsorship deals within your desired budget range</span>
                </li>
                <li className="flex items-start">
                  <CheckIcon className="text-amber-400 h-5 w-5 mt-1 mr-3" />
                  <span>Access promotional resources and campaign tracking tools</span>
                </li>
              </ul>
              <Link href="/sponsorships?type=creator">
                <Button className="w-full py-3 bg-white text-primary-700 hover:bg-gray-100">
                  Find Sponsors
                </Button>
              </Link>
            </div>
            
            {/* Sponsor Card */}
            <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl overflow-hidden shadow-lg p-8 text-white">
              <div className="flex items-center justify-center mb-6">
                <svg className="h-16 w-16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M9 22V12H15V22" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-center mb-6">I'm a Sponsor</h3>
              <ul className="space-y-4 mb-8">
                <li className="flex items-start">
                  <CheckIcon className="text-amber-400 h-5 w-5 mt-1 mr-3" />
                  <span>Connect with gaming creators that match your target audience</span>
                </li>
                <li className="flex items-start">
                  <CheckIcon className="text-amber-400 h-5 w-5 mt-1 mr-3" />
                  <span>Set your budget range and campaign requirements</span>
                </li>
                <li className="flex items-start">
                  <CheckIcon className="text-amber-400 h-5 w-5 mt-1 mr-3" />
                  <span>Track campaign performance and manage partnerships</span>
                </li>
              </ul>
              <Link href="/sponsorships?type=sponsor">
                <Button className="w-full py-3 bg-amber-500 text-gray-900 hover:bg-amber-600">
                  Find Creators
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* AI Tools Preview */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">AI-Powered Tools</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Supercharge your productivity and content creation with our suite of AI assistants.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center gap-4 pb-2">
                <div className="w-12 h-12 rounded-full bg-primary-100 text-primary flex items-center justify-center">
                  <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <h3 className="font-bold">Task Assistant</h3>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-500">Keep track of content creation deadlines and manage your schedule efficiently.</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center gap-4 pb-2">
                <div className="w-12 h-12 rounded-full bg-primary-100 text-primary flex items-center justify-center">
                  <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2L22 8.5M12 2L2 8.5M12 2V22M22 8.5V15.5L12 22M22 8.5L12 15.5M2 8.5L12 15.5M2 8.5V15.5L12 22M12 15.5V22" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <h3 className="font-bold">Fitness Coach</h3>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-500">Customized exercises and health tips for content creators who spend long hours at their desk.</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center gap-4 pb-2">
                <div className="w-12 h-12 rounded-full bg-primary-100 text-primary flex items-center justify-center">
                  <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <h3 className="font-bold">Learning Assistant</h3>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-500">Personalized tutorials and learning paths to improve your content creation skills.</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center gap-4 pb-2">
                <div className="w-12 h-12 rounded-full bg-primary-100 text-primary flex items-center justify-center">
                  <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707M12 21v-1m-9-9a9 9 0 1118 0 9 9 0 01-18 0z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <h3 className="font-bold">Idea Generator</h3>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-500">Never run out of content ideas with AI-generated suggestions based on your niche.</p>
              </CardContent>
            </Card>
          </div>
          
          <div className="mt-10 text-center">
            <Link href="/ai-tools" className="inline-flex items-center text-primary hover:text-primary-700 font-medium">
              Explore all AI tools
              <ArrowRightIcon className="ml-1 h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-primary-700 to-primary-900 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Ready to Level Up Your Content Creation?</h2>
            <p className="text-lg mb-8 opacity-90">Join thousands of creators who are growing their channels, finding sponsors, and building their online presence with CreatorHub.</p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link href="/register">
                <Button size="lg" className="px-6 py-3 bg-amber-500 text-gray-900 hover:bg-amber-600 border-0">
                  Sign Up - Free Trial
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="px-6 py-3 bg-white text-primary-800 hover:bg-gray-100 border-0">
                See Pricing Plans
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
