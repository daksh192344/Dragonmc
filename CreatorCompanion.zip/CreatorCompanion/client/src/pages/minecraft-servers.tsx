import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MinecraftServer } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { CheckIcon } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

export default function MinecraftServers() {
  const { data: servers, isLoading } = useQuery<MinecraftServer[]>({
    queryKey: ['/api/minecraft-servers'],
  });

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Minecraft Server Solutions</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Launch your perfect Minecraft server with our pre-configured game modes at affordable prices.
          All servers come with 24/7 uptime, DDoS protection, and easy setup.
        </p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {Array(8).fill(0).map((_, index) => (
            <div key={index} className="rounded-xl border border-gray-200 bg-white shadow-md p-6 animate-pulse">
              <div className="h-40 bg-gray-200 rounded-lg mb-4"></div>
              <div className="h-6 bg-gray-200 rounded w-1/2 mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
              <div className="h-10 bg-gray-200 rounded-lg"></div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {servers?.map((server) => (
            <div
              key={server.id}
              className="pricing-card rounded-xl overflow-hidden border border-gray-200 bg-white shadow-md transition-transform hover:-translate-y-1 hover:shadow-lg"
            >
              <div className={`h-40 ${server.popular ? 'bg-primary-700' : 'bg-primary-600'} relative flex items-center justify-center`}>
                {server.popular && (
                  <div className="absolute top-3 right-3 bg-amber-500 text-black text-xs font-bold px-2 py-1 rounded-full">
                    BEST VALUE
                  </div>
                )}
                <h3 className="text-2xl font-bold text-white relative z-10">{server.name}</h3>
              </div>
              <div className="p-6">
                <div className="flex justify-center mb-4">
                  <span className="text-3xl font-bold text-gray-900">
                    ₹{server.price}
                    <span className="text-lg font-normal text-gray-500">/mo</span>
                  </span>
                </div>
                <ul className="mb-6 space-y-2">
                  {server.features?.map((feature, index) => (
                    <li key={index} className="flex items-center text-sm text-gray-600">
                      <CheckIcon className="text-green-500 mr-2 h-4 w-4" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button 
                  className="w-full" 
                  variant={server.popular ? "default" : "secondary"}
                >
                  Get Started
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-16 bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-8">
          <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>
          <div className="grid gap-6 md:grid-cols-2">
            <div>
              <h3 className="font-bold text-lg mb-2">What's included in all servers?</h3>
              <p className="text-gray-600">
                All our Minecraft servers include 24/7 uptime, DDoS protection, automated backups, 
                custom domain support, and a control panel for easy management.
              </p>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-2">How do I get started?</h3>
              <p className="text-gray-600">
                Simply select your preferred package, complete payment, and your server will be 
                set up within minutes. You'll receive login details to your control panel via email.
              </p>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-2">Can I change game modes later?</h3>
              <p className="text-gray-600">
                Yes, you can upgrade or switch your game mode at any time. Your world data can be 
                transferred if you wish to keep your progress.
              </p>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-2">Do you offer custom mods/plugins?</h3>
              <p className="text-gray-600">
                Yes, all servers support custom plugins and mods. The All Gamemodes package includes 
                additional support for complex mod setups and configurations.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Need a Custom Solution?</h2>
        <p className="text-gray-600 max-w-2xl mx-auto mb-6">
          If you need a custom server configuration or have specific requirements,
          our team can help build the perfect solution for your needs.
        </p>
        <Button size="lg">Contact for Custom Quote</Button>
      </div>
    </div>
  );
}
