import Header from "../components/header";
import Footer from "../components/footer";
import { useLocation } from "wouter";

interface MainLayoutProps {
  children: React.ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const [location] = useLocation();
  
  // Determine if the current route is a public page that should have the header and footer
  // Dashboard and profile pages might have a different layout
  const isDashboardRoute = location.startsWith("/dashboard") || location === "/profile";
  
  // Login and register pages might have a minimal layout
  const isAuthRoute = location === "/login" || location === "/register";
  
  if (isAuthRoute) {
    return (
      <div className="min-h-screen bg-gray-50">
        {children}
      </div>
    );
  }
  
  if (isDashboardRoute) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-grow pt-20">
          {children}
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <div className="flex-grow pt-20">
        {children}
      </div>
      <Footer />
    </div>
  );
}
