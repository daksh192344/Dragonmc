import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
  navItems: {
    href: string;
    name: string;
  }[];
}

export default function MobileMenu({ isOpen, onClose, navItems }: MobileMenuProps) {
  // Prevent body scrolling when menu is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-gray-900 bg-opacity-50">
      <div className="h-full w-64 bg-white p-5 transform transition-transform">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold font-sans text-gray-900">CreatorHub</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-6 w-6" />
          </Button>
        </div>
        <nav className="flex flex-col space-y-4">
          {navItems.map((item) => (
            <Link 
              key={item.href} 
              href={item.href} 
              className="text-gray-900 hover:text-primary font-medium py-2 transition-colors"
              onClick={onClose}
            >
              {item.name}
            </Link>
          ))}
          <div className="pt-4 border-t">
            <Link href="/login" onClick={onClose}>
              <Button variant="outline" className="w-full mb-3">
                Login
              </Button>
            </Link>
            <Link href="/register" onClick={onClose}>
              <Button className="w-full">
                Sign Up
              </Button>
            </Link>
          </div>
        </nav>
      </div>
    </div>
  );
}
