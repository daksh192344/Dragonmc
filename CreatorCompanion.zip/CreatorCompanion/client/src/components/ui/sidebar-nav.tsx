import { cn } from "@/lib/utils";
import { Link, useLocation } from "wouter";

interface SidebarNavProps extends React.HTMLAttributes<HTMLElement> {
  items: {
    href: string;
    title: string;
    icon?: React.ReactNode;
  }[];
}

export function SidebarNav({ className, items, ...props }: SidebarNavProps) {
  const [location] = useLocation();

  return (
    <nav
      className={cn(
        "flex space-x-2 lg:flex-col lg:space-x-0 lg:space-y-1",
        className
      )}
      {...props}
    >
      {items.map((item) => (
        <Link
          key={item.href}
          href={item.href}
          className={cn(
            "flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
            location === item.href
              ? "bg-primary text-primary-foreground"
              : "hover:bg-primary/10 hover:text-primary"
          )}
        >
          {item.icon && <span className="w-4 h-4">{item.icon}</span>}
          {item.title}
        </Link>
      ))}
    </nav>
  );
}
