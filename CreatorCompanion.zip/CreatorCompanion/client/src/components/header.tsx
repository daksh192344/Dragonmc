import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { PencilLine } from "lucide-react";
import MobileMenu from "./mobile-menu";

export default function Header() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { href: "/", name: "Home" },
    { href: "/minecraft-servers", name: "Minecraft Servers" },
    { href: "/creator-resources", name: "Creator Resources" },
    { href: "/sponsorships", name: "Sponsorships" },
    { href: "/ai-tools", name: "AI Tools" },
  ];

  return (
    <header className="bg-white border-b border-gray-200 fixed w-full z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-2">
            <PencilLine className="w-8 h-8 text-primary" />
            <h1 className="text-xl font-bold font-sans text-gray-900">
              Creator<span className="text-primary">Hub</span>
            </h1>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            {navItems.map((item) => (
              <Link 
                key={item.href} 
                href={item.href}
                className={`text-gray-900 hover:text-primary font-medium transition-colors ${
                  location === item.href ? "text-primary" : ""
                }`}
              >
                {item.name}
              </Link>
            ))}
          </nav>
          
          <div className="flex items-center space-x-4">
            <Link href="/login">
              <Button 
                variant="outline" 
                className="hidden md:block"
              >
                Login
              </Button>
            </Link>
            <Link href="/register">
              <Button>Sign Up</Button>
            </Link>
            <Button 
              variant="ghost" 
              className="md:hidden p-2" 
              onClick={() => setMobileMenuOpen(true)}
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </Button>
          </div>
        </div>
      </div>

      <MobileMenu 
        isOpen={mobileMenuOpen} 
        onClose={() => setMobileMenuOpen(false)} 
        navItems={navItems}
      />
    </header>
  );
}
