import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  isCreator: boolean("is_creator").default(false),
  isSponsor: boolean("is_sponsor").default(false),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  isCreator: true,
  isSponsor: true,
});

// Creator Profile schema
export const creatorProfiles = pgTable("creator_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  channelName: text("channel_name").notNull(),
  channelUrl: text("channel_url"),
  subscribers: integer("subscribers").default(0),
  niche: text("niche"),
  description: text("description"),
  minBudget: integer("min_budget").default(0),
});

export const insertCreatorProfileSchema = createInsertSchema(creatorProfiles).pick({
  userId: true,
  channelName: true,
  channelUrl: true,
  subscribers: true,
  niche: true,
  description: true,
  minBudget: true,
});

// Sponsor Profile schema
export const sponsorProfiles = pgTable("sponsor_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  companyName: text("company_name").notNull(),
  website: text("website"),
  industry: text("industry"),
  description: text("description"),
  budget: integer("budget").default(0),
});

export const insertSponsorProfileSchema = createInsertSchema(sponsorProfiles).pick({
  userId: true,
  companyName: true,
  website: true,
  industry: true,
  description: true,
  budget: true,
});

// Minecraft Server Options schema
export const minecraftServers = pgTable("minecraft_servers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  price: integer("price").notNull(), // in rupees
  ram: integer("ram").notNull(), // in GB
  gameMode: text("game_mode").notNull(),
  players: integer("players").notNull(),
  features: text("features").array(),
  popular: boolean("popular").default(false),
});

export const insertMinecraftServerSchema = createInsertSchema(minecraftServers).pick({
  name: true,
  price: true,
  ram: true,
  gameMode: true,
  players: true,
  features: true,
  popular: true,
});

// Creator Resources schema
export const creatorResources = pgTable("creator_resources", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // guide, template, setup, editing, coding, business
  downloadUrl: text("download_url"),
  thumbnail: text("thumbnail"),
  details: text("details"),
});

export const insertCreatorResourceSchema = createInsertSchema(creatorResources).pick({
  title: true,
  description: true,
  category: true,
  downloadUrl: true,
  thumbnail: true,
  details: true,
});

// Tasks schema
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  completed: boolean("completed").default(false),
  dueDate: timestamp("due_date"),
  priority: text("priority").default("medium"),
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  userId: true,
  title: true,
  completed: true,
  dueDate: true,
  priority: true,
});

// Fitness Recommendations schema
export const fitnessRecommendations = pgTable("fitness_recommendations", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // stretching, cardio, eyes, mental, etc.
  duration: integer("duration").default(5), // in minutes
});

export const insertFitnessRecommendationSchema = createInsertSchema(fitnessRecommendations).pick({
  title: true,
  description: true,
  category: true,
  duration: true,
});

// Business Ideas schema
export const businessIdeas = pgTable("business_ideas", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
});

export const insertBusinessIdeaSchema = createInsertSchema(businessIdeas).pick({
  title: true,
  description: true,
  category: true,
});

// Learning Resources schema
export const learningResources = pgTable("learning_resources", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  progress: integer("progress").default(0), // 0-100
});

export const insertLearningResourceSchema = createInsertSchema(learningResources).pick({
  title: true,
  description: true,
  category: true,
  progress: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type CreatorProfile = typeof creatorProfiles.$inferSelect;
export type InsertCreatorProfile = z.infer<typeof insertCreatorProfileSchema>;

export type SponsorProfile = typeof sponsorProfiles.$inferSelect;
export type InsertSponsorProfile = z.infer<typeof insertSponsorProfileSchema>;

export type MinecraftServer = typeof minecraftServers.$inferSelect;
export type InsertMinecraftServer = z.infer<typeof insertMinecraftServerSchema>;

export type CreatorResource = typeof creatorResources.$inferSelect;
export type InsertCreatorResource = z.infer<typeof insertCreatorResourceSchema>;

export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;

export type FitnessRecommendation = typeof fitnessRecommendations.$inferSelect;
export type InsertFitnessRecommendation = z.infer<typeof insertFitnessRecommendationSchema>;

export type BusinessIdea = typeof businessIdeas.$inferSelect;
export type InsertBusinessIdea = z.infer<typeof insertBusinessIdeaSchema>;

export type LearningResource = typeof learningResources.$inferSelect;
export type InsertLearningResource = z.infer<typeof insertLearningResourceSchema>;
